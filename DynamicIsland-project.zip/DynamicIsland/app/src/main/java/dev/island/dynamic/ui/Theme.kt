package dev.island.dynamic.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Headings and subheadings use a light serif, like the big "Settings" title in Nothing OS.
 * Nothing's own typeface is proprietary and can't be bundled, so this uses Android's built-in
 * serif. To use a font file you have the right to use, put it in res/font/ and replace
 * FontFamily.Serif below with FontFamily(Font(R.font.your_font)).
 */
private val HeadingFont = FontFamily.Serif

private val IslandTypography: Typography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(
            fontFamily = HeadingFont,
            fontWeight = FontWeight.Normal,
            fontSize = 40.sp,
            lineHeight = 46.sp,
        ),
        titleLarge = base.titleLarge.copy(fontFamily = HeadingFont, fontWeight = FontWeight.Normal),
        titleMedium = base.titleMedium.copy(
            fontFamily = HeadingFont,
            fontWeight = FontWeight.Normal,
            fontSize = 20.sp,
            lineHeight = 26.sp,
        ),
    )
}

@Composable
fun IslandTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(context)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, typography = IslandTypography, content = content)
}
