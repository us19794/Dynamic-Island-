package dev.island.dynamic.ui.namedrop

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.island.dynamic.model.NameDropRequest
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

private val GlowBlue = Color(0xFF4FC3F7)
private val GlowPurple = Color(0xFF7C4DFF)
private val GlowGrey = Color(0xFFB4B7BE)
private val CardColor = Color(0xFF1C1C1E)
private val ButtonDark = Color(0xFF2C2C2E)
private val DetailGray = Color(0xFF8E8E93)

/** Accessible blue for button text/fill. The glow blue is too light for white text. */
private val ActionBlue = Color(0xFF0A84FF)

private val TwoPi = (2.0 * PI).toFloat()

/** TUNING: every number that defines how NameDrop feels lives here. */
object NameDropMotion {
    /** Card appears this long after the glow starts. */
    const val CARD_DELAY_MS = 350L

    const val GLOW_IN_MS = 520
    const val GLOW_OUT_MS = 380

    /** One full left-right-left sweep of the glows. */
    const val DRIFT_MS = 6000

    /** One full breathe in/out of the glows. */
    const val PULSE_MS = 2400

    /** < 1 bounces. 0.58 is noticeable, 0.8 is subtle, 1.0 has no bounce. */
    const val CARD_DAMPING = 0.58f
    const val CARD_STIFFNESS = 280f

    /** Dark layer behind the glow. Set to 0f to remove. */
    const val SCRIM_ALPHA = 0.35f

    val CardCorner = 32.dp
    val CardBottomMargin = 56.dp
}

/**
 * Soft blue / purple / grey light spilling down from the top edge, pulsing gently.
 * Blue + purple drift one way while grey drifts the other.
 *
 * Everything animated is read inside the draw lambda, so nothing recomposes per frame.
 * Nothing is composed (and no infinite animation runs) while the glow is fully faded out.
 */
@Composable
fun NameDropGlow(
    active: Boolean,
    modifier: Modifier = Modifier,
    onFadedOut: () -> Unit = {},
) {
    val intro = remember { Animatable(0f) }
    val fadedOut = rememberUpdatedState(onFadedOut)
    var drawing by remember { mutableStateOf(false) }

    LaunchedEffect(active) {
        if (active) {
            drawing = true
            intro.animateTo(1f, tween(NameDropMotion.GLOW_IN_MS, easing = FastOutSlowInEasing))
        } else {
            intro.animateTo(0f, tween(NameDropMotion.GLOW_OUT_MS, easing = FastOutLinearInEasing))
            drawing = false
            fadedOut.value()
        }
    }

    if (drawing) GlowCanvas(intro = { intro.value }, modifier = modifier)
}

@Composable
private fun GlowCanvas(intro: () -> Float, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "nameDropGlow")
    val drift = transition.animateFloat(
        initialValue = 0f,
        targetValue = TwoPi,
        animationSpec = infiniteRepeatable(tween(NameDropMotion.DRIFT_MS, easing = LinearEasing)),
        label = "drift",
    )
    val pulse = transition.animateFloat(
        initialValue = 0f,
        targetValue = TwoPi,
        animationSpec = infiniteRepeatable(tween(NameDropMotion.PULSE_MS, easing = LinearEasing)),
        label = "pulse",
    )
    val blue = remember { glowBrush(GlowBlue) }
    val purple = remember { glowBrush(GlowPurple) }
    val grey = remember { glowBrush(GlowGrey) }

    Canvas(modifier) {
        val k = intro()
        if (k <= 0.001f) return@Canvas

        val w = size.width
        val sweep = sin(drift.value)                       // -1..1, slow
        val breathe = 1f + 0.08f * sin(pulse.value)        // radius pulse
        val shimmer = 0.88f + 0.12f * sin(pulse.value + 1.3f) // brightness pulse
        val grow = 0.65f + 0.35f * k                       // glow spreads as it fades in
        val a = k * shimmer

        // Blue and purple drift together; grey drifts the opposite way.
        blob(blue, w * 0.22f + sweep * w * 0.16f, w * 0.80f * breathe * grow, a)
        blob(purple, w * 0.62f + sweep * w * 0.16f, w * 0.85f * breathe * grow, a)
        blob(grey, w * 0.45f - sweep * w * 0.18f, w * 0.70f * breathe * grow, a)
    }
}

/** Unit-radius gradient: placed and sized with translate/scale, so no per-frame allocation. */
private fun glowBrush(color: Color): Brush = Brush.radialGradient(
    0f to color.copy(alpha = 0.90f),
    0.35f to color.copy(alpha = 0.45f),
    1f to color.copy(alpha = 0f),
    center = Offset.Zero,
    radius = 1f,
)

private fun DrawScope.blob(brush: Brush, x: Float, radius: Float, alpha: Float) {
    translate(left = x, top = 0f) {
        scale(scale = radius, pivot = Offset.Zero) {
            drawCircle(brush = brush, radius = 1f, center = Offset.Zero, alpha = alpha)
        }
    }
}

/**
 * Dark contact card. Slides up with a spring bounce and fades in [NameDropMotion.CARD_DELAY_MS]
 * after becoming visible; slides down and fades out when [visible] turns false.
 * Taps on the card are swallowed so they never reach the "tap outside" handler.
 */
@Composable
private fun NameDropCard(
    visible: Boolean,
    name: String,
    detail: String,
    onShare: () -> Unit,
    onReceiveOnly: () -> Unit,
    onHidden: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val extraTravelPx = with(density) { NameDropMotion.CardBottomMargin.toPx() }
    val progress = remember { Animatable(0f) } // 0 = off screen, 1 = resting; >1 = bounce
    val fade = remember { Animatable(0f) }
    val hidden = rememberUpdatedState(onHidden)

    LaunchedEffect(visible) {
        if (visible) {
            delay(NameDropMotion.CARD_DELAY_MS)
            coroutineScope {
                launch {
                    progress.animateTo(
                        1f,
                        spring(
                            dampingRatio = NameDropMotion.CARD_DAMPING,
                            stiffness = NameDropMotion.CARD_STIFFNESS,
                        ),
                    )
                }
                launch { fade.animateTo(1f, tween(240)) }
            }
        } else {
            coroutineScope {
                launch { progress.animateTo(0f, spring(dampingRatio = 1f, stiffness = 420f)) }
                launch { fade.animateTo(0f, tween(200)) }
            }
            hidden.value()
        }
    }

    val avatarBrush = remember { Brush.linearGradient(listOf(GlowBlue, GlowPurple, GlowGrey)) }
    val initial = remember(name) { name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?" }
    val swallowTaps = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .padding(horizontal = 20.dp)
            .padding(bottom = NameDropMotion.CardBottomMargin)
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .graphicsLayer {
                translationY = (1f - progress.value) * (size.height + extraTravelPx)
                alpha = fade.value
            }
            .clip(RoundedCornerShape(NameDropMotion.CardCorner))
            .background(CardColor)
            .clickable(interactionSource = swallowTaps, indication = null, onClick = {})
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(avatarBrush),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = initial,
                color = Color.White,
                fontSize = 38.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = name,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = detail,
            color = DetailGray,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(24.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ActionButton("Receive Only", ButtonDark, ActionBlue, onReceiveOnly)
            ActionButton("Share", ActionBlue, Color.White, onShare)
        }
    }
}

@Composable
private fun RowScope.ActionButton(
    label: String,
    background: Color,
    textColor: Color,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .weight(1f)
            .height(52.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/**
 * Glow + card + a light scrim, with tap-outside-to-dismiss.
 *
 * [onExited] is called once everything has finished animating out, so the host can remove the
 * window. It is an addition to the basic signature and defaults to a no-op.
 */
@Composable
fun NameDropOverlay(
    active: Boolean,
    name: String,
    detail: String,
    onShare: () -> Unit,
    onReceiveOnly: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    onExited: () -> Unit = {},
) {
    val isActive = rememberUpdatedState(active)
    val dismiss = rememberUpdatedState(onDismiss)
    val exited = rememberUpdatedState(onExited)

    // Both start "hidden" and only flip to false once we have been active, so onExited fires
    // exactly when the last piece has finished leaving.
    var glowHidden by remember { mutableStateOf(true) }
    var cardHidden by remember { mutableStateOf(true) }
    LaunchedEffect(active) {
        if (active) {
            glowHidden = false
            cardHidden = false
        }
    }
    LaunchedEffect(active, glowHidden, cardHidden) {
        if (!active && glowHidden && cardHidden) exited.value()
    }

    val scrim = animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(if (active) NameDropMotion.GLOW_IN_MS else NameDropMotion.GLOW_OUT_MS),
        label = "nameDropScrim",
    )

    Box(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(Color.Black, alpha = NameDropMotion.SCRIM_ALPHA * scrim.value)
            }
            // Anything not consumed by the card (or its buttons) is "outside".
            .pointerInput(Unit) {
                detectTapGestures { if (isActive.value) dismiss.value() }
            },
    ) {
        NameDropGlow(
            active = active,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.55f),
            onFadedOut = { glowHidden = true },
        )
        NameDropCard(
            visible = active,
            name = name,
            detail = detail,
            onShare = onShare,
            onReceiveOnly = onReceiveOnly,
            onHidden = { cardHidden = true },
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

/**
 * Binds NameDropOverlay to a request flow. The last request is remembered so the name and
 * detail stay on the card while it animates out after the flow goes back to null.
 */
@Composable
fun NameDropHost(
    requestFlow: StateFlow<NameDropRequest?>,
    onDismiss: () -> Unit,
    onExited: () -> Unit,
) {
    val request by requestFlow.collectAsState()
    var last by remember { mutableStateOf(request) }
    LaunchedEffect(request) {
        if (request != null) last = request
    }
    NameDropOverlay(
        active = request != null,
        name = last?.name.orEmpty(),
        detail = last?.detail.orEmpty(),
        onShare = onDismiss,
        onReceiveOnly = onDismiss,
        onDismiss = onDismiss,
        onExited = onExited,
    )
}
