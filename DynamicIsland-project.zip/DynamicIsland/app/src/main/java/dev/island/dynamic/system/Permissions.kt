package dev.island.dynamic.system

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class PermissionSnapshot(
    val overlay: Boolean,
    val postNotifications: Boolean,
    val notificationAccess: Boolean,
    val batteryUnrestricted: Boolean,
    val accessibility: Boolean,
)

object Permissions {

    fun snapshot(c: Context) = PermissionSnapshot(
        overlay = hasOverlay(c),
        postNotifications = hasPostNotifications(c),
        notificationAccess = hasNotificationAccess(c),
        batteryUnrestricted = isBatteryUnrestricted(c),
        accessibility = isAccessibilityEnabled(c),
    )

    fun hasOverlay(c: Context): Boolean = Settings.canDrawOverlays(c)

    fun hasPostNotifications(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun hasNotificationAccess(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    fun isBatteryUnrestricted(c: Context): Boolean {
        val pm = c.getSystemService(PowerManager::class.java) ?: return false
        return pm.isIgnoringBatteryOptimizations(c.packageName)
    }

    fun isAccessibilityEnabled(c: Context): Boolean {
        val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(c, IslandAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun pkgUri(c: Context) = Uri.parse("package:${c.packageName}")

    fun overlaySettingsIntent(c: Context) =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri(c))

    fun notificationAccessIntent() = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)

    fun appDetailsIntent(c: Context) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(c))

    fun batteryRequestIntent(c: Context) =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(c))

    fun batteryListIntent() = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    fun accessibilityIntent() = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
}
