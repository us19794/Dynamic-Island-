package dev.island.dynamic.model

import android.os.SystemClock
import androidx.compose.runtime.Immutable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@Immutable
data class NameDropRequest(
    val name: String,
    val detail: String,
    val createdAtElapsed: Long,
)

/**
 * Animation-only trigger. Anything can call [show]; OverlayService watches [request] and
 * puts the NameDrop window on screen. There is no NFC, proximity or networking behind it.
 */
object NameDropBus {
    const val PLACEHOLDER_NAME = "Alex Rivera"
    const val PLACEHOLDER_DETAIL = "+1 (555) 010-0199"

    /** A request older than this that never got shown is considered stale and replaced. */
    private const val STALE_MS = 5_000L

    private val mutableRequest = MutableStateFlow<NameDropRequest?>(null)
    val request: StateFlow<NameDropRequest?> = mutableRequest.asStateFlow()

    fun show(name: String = PLACEHOLDER_NAME, detail: String = PLACEHOLDER_DETAIL) {
        val now = SystemClock.elapsedRealtime()
        val current = mutableRequest.value
        if (current != null && now - current.createdAtElapsed < STALE_MS) return
        mutableRequest.value = NameDropRequest(name, detail, now)
    }

    fun dismiss() {
        mutableRequest.value = null
    }
}
