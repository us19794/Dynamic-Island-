package dev.island.dynamic

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import dev.island.dynamic.system.OverlayService
import dev.island.dynamic.system.Permissions
import dev.island.dynamic.ui.AppFilterScreen
import dev.island.dynamic.ui.IslandTheme
import dev.island.dynamic.ui.OnboardingScreen
import dev.island.dynamic.ui.SettingsScreen
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import dev.island.dynamic.settings.Keys

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IslandTheme {
                Surface(Modifier.fillMaxSize()) { AppRoot() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        startIslandIfPossible(this)
    }
}

fun startIslandIfPossible(context: Context) {
    if (Permissions.hasOverlay(context) && ServiceLocator.settings.value.serviceEnabled) {
        ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by ServiceLocator.settings.collectAsState()
    var perms by remember { mutableStateOf(Permissions.snapshot(context)) }
    var showSetup by rememberSaveable { mutableStateOf(false) }
    var showApps by rememberSaveable { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        perms = Permissions.snapshot(context)
        startIslandIfPossible(context)
    }

    if (!settings.loaded) {
        Box(Modifier.fillMaxSize())
        return
    }

    val needsSetup = !settings.onboardingDone || !perms.overlay

    BackHandler(enabled = showApps || (showSetup && !needsSetup)) {
        showApps = false
        showSetup = false
    }

    when {
        needsSetup || showSetup -> OnboardingScreen(
            perms = perms,
            onFinish = {
                scope.launch { ServiceLocator.repo.set(Keys.ONBOARDING_DONE, true) }
                showSetup = false
                startIslandIfPossible(context)
            },
        )
        showApps -> AppFilterScreen(onBack = { showApps = false })
        else -> SettingsScreen(
            onOpenApps = { showApps = true },
            onOpenSetup = { showSetup = true },
        )
    }
}
