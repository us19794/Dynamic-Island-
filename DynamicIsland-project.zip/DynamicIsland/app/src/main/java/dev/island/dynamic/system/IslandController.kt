package dev.island.dynamic.system

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import dev.island.dynamic.model.CallInfo
import dev.island.dynamic.model.IslandActions
import dev.island.dynamic.model.IslandEvent
import dev.island.dynamic.model.IslandState
import dev.island.dynamic.model.IslandStateMachine
import dev.island.dynamic.model.MediaInfo
import dev.island.dynamic.model.NameDropBus
import dev.island.dynamic.model.NotificationInfo
import dev.island.dynamic.settings.IslandSettings
import kotlinx.coroutines.flow.StateFlow

/** Turns UI gestures into state-machine events and platform side effects. */
class IslandController(
    private val context: Context,
    private val machine: IslandStateMachine,
    private val settings: StateFlow<IslandSettings>,
) : IslandActions {

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            context.getSystemService(Vibrator::class.java)
        }

    override fun onTap(state: IslandState) {
        machine.dispatch(IslandEvent.Interaction)
        when (state) {
            IslandState.Idle -> Unit
            is IslandState.Compact -> {
                val p = state.primary
                if (p is MediaInfo || (p is CallInfo && !p.isIncoming)) expand()
            }
            is IslandState.Banner -> when (val p = state.primary) {
                is NotificationInfo -> {
                    if (!send(p.contentIntent)) openApp(p.packageName)
                    machine.dispatch(IslandEvent.NotificationRemoved(p.id))
                }
                is CallInfo ->
                    if (p.isIncoming) send(p.contentIntent) else machine.dispatch(IslandEvent.Collapse)
                else -> Unit
            }
            is IslandState.Expanded -> machine.dispatch(IslandEvent.Collapse)
        }
    }

    override fun onLongPress(state: IslandState) {
        machine.dispatch(IslandEvent.Interaction)
        when (state) {
            // Nothing else uses a long-press on the idle island, so it triggers NameDrop.
            IslandState.Idle -> {
                haptic()
                NameDropBus.show()
            }
            is IslandState.Compact -> {
                val p = state.primary
                if (p is MediaInfo || (p is CallInfo && !p.isIncoming)) expand()
            }
            is IslandState.Banner -> {
                val p = state.primary
                if (p is NotificationInfo) machine.dispatch(IslandEvent.NotificationRemoved(p.id))
            }
            is IslandState.Expanded -> openApp(state.primary.packageName)
        }
    }

    override fun onSwipe(direction: Int) {
        machine.dispatch(IslandEvent.Swipe(direction))
        machine.dispatch(IslandEvent.Interaction)
    }

    override fun onOutsideTouch() {
        machine.dispatch(IslandEvent.Collapse)
    }

    override fun togglePlayPause(info: MediaInfo) {
        val controls = MediaBridge.controller?.transportControls
        if (controls != null) {
            if (info.isPlaying) controls.pause() else controls.play()
        }
        machine.dispatch(IslandEvent.Interaction)
    }

    override fun next() {
        MediaBridge.controller?.transportControls?.skipToNext()
        machine.dispatch(IslandEvent.Interaction)
    }

    override fun previous() {
        MediaBridge.controller?.transportControls?.skipToPrevious()
        machine.dispatch(IslandEvent.Interaction)
    }

    override fun seekTo(positionMs: Long) {
        MediaBridge.controller?.transportControls?.seekTo(positionMs)
        machine.dispatch(IslandEvent.Interaction)
    }

    override fun answer(call: CallInfo) {
        send(call.answerIntent)
    }

    override fun decline(call: CallInfo) {
        send(call.declineIntent)
    }

    override fun openApp(packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return
        try {
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }

    private fun expand() {
        haptic()
        machine.dispatch(IslandEvent.Expand)
    }

    private fun haptic() {
        if (!settings.value.hapticsEnabled) return
        try {
            vibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
        } catch (_: Throwable) {
        }
    }

    private fun send(pendingIntent: PendingIntent?): Boolean {
        if (pendingIntent == null) return false
        return try {
            if (Build.VERSION.SDK_INT >= 34) {
                val options = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                    .toBundle()
                pendingIntent.send(context, 0, null, null, null, null, options)
            } else {
                pendingIntent.send()
            }
            true
        } catch (_: PendingIntent.CanceledException) {
            false
        }
    }
}
