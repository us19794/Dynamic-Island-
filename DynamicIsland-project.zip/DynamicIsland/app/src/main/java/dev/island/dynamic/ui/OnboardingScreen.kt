package dev.island.dynamic.ui

import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.island.dynamic.system.PermissionSnapshot
import dev.island.dynamic.system.Permissions

private class Step(
    val title: String,
    val body: String,
    val done: Boolean,
    val optional: Boolean,
    val primaryLabel: String,
    val onPrimary: () -> Unit,
    val secondaryLabel: String? = null,
    val onSecondary: (() -> Unit)? = null,
)

@Composable
fun OnboardingScreen(perms: PermissionSnapshot, onFinish: () -> Unit) {
    val context = LocalContext.current

    fun launch(intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            Toast.makeText(context, "Couldn't open that settings page", Toast.LENGTH_SHORT).show()
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val steps = listOf(
        Step(
            title = "1. Display over other apps",
            body = "Lets the island draw above every app, around your camera. Find Island in the list and switch it on.",
            done = perms.overlay,
            optional = false,
            primaryLabel = "Open setting",
            onPrimary = { launch(Permissions.overlaySettingsIntent(context)) },
        ),
        Step(
            title = "2. Notifications",
            body = "Needed so Android shows the small \"Island is running\" notification that keeps the service alive.",
            done = perms.postNotifications,
            optional = false,
            primaryLabel = "Allow",
            onPrimary = {
                if (Build.VERSION.SDK_INT >= 33) {
                    notificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            },
        ),
        Step(
            title = "3. Allow restricted settings",
            body = "Because this app was installed from an APK, Android 16 blocks Notification access until you allow it.\n\n" +
                "Settings > Apps > Island > top-right \u22EE menu > Allow restricted settings.\n\n" +
                "Tip: the \u22EE menu only appears after you have tried step 4 once and been blocked. " +
                "Do step 4, get the warning, come back here, allow it, then repeat step 4.",
            done = perms.notificationAccess,
            optional = false,
            primaryLabel = "Open App info",
            onPrimary = { launch(Permissions.appDetailsIntent(context)) },
        ),
        Step(
            title = "4. Notification access",
            body = "Lets the island read notifications, now-playing media and incoming calls. Switch Island on.",
            done = perms.notificationAccess,
            optional = false,
            primaryLabel = "Open setting",
            onPrimary = { launch(Permissions.notificationAccessIntent()) },
        ),
        Step(
            title = "5. Battery: Unrestricted",
            body = "Nothing OS aggressively kills background apps, which would make the island vanish. " +
                "Set Battery to Unrestricted. Also open Recents, long-press Island's card and tap Lock.",
            done = perms.batteryUnrestricted,
            optional = false,
            primaryLabel = "Allow unrestricted",
            onPrimary = { launch(Permissions.batteryRequestIntent(context)) },
            secondaryLabel = "App battery settings",
            onSecondary = { launch(Permissions.appDetailsIntent(context)) },
        ),
        Step(
            title = "6. Hide in fullscreen (optional)",
            body = "Turn on Island under Accessibility > Installed apps to hide the island in fullscreen apps. " +
                "It only checks window sizes and never reads your screen. You may need \"Allow restricted settings\" again.",
            done = perms.accessibility,
            optional = true,
            primaryLabel = "Open setting",
            onPrimary = { launch(Permissions.accessibilityIntent()) },
        ),
    )

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text("Set up Island", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Do these in order. Each step turns green when it's done.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            itemsIndexed(steps) { _, step -> StepCard(step) }
            item {
                Button(
                    onClick = onFinish,
                    enabled = perms.overlay,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (perms.overlay) "Finish and start island" else "Grant step 1 to continue") }
            }
        }
    }
}

@Composable
private fun StepCard(step: Step) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    step.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = when {
                        step.done -> "Done"
                        step.optional -> "Optional"
                        else -> "To do"
                    },
                    color = if (step.done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
            Text(step.body, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (step.done) {
                    OutlinedButton(onClick = step.onPrimary) { Text(step.primaryLabel) }
                } else {
                    Button(onClick = step.onPrimary) { Text(step.primaryLabel) }
                }
                val label = step.secondaryLabel
                val action = step.onSecondary
                if (label != null && action != null) {
                    OutlinedButton(onClick = action) { Text(label) }
                }
            }
        }
    }
}
