package dev.island.dynamic.ui.island

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.island.dynamic.model.CallInfo
import dev.island.dynamic.model.ChargingInfo
import dev.island.dynamic.model.IslandActions
import dev.island.dynamic.model.IslandActivity
import dev.island.dynamic.model.IslandState
import dev.island.dynamic.model.MediaInfo
import dev.island.dynamic.model.NotificationInfo
import dev.island.dynamic.model.form
import dev.island.dynamic.system.IslandGeometry
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

private val Gray = Color(0xFF9A9AA0)
private val Green = Color(0xFF30D158)
private val Red = Color(0xFFFF453A)
private val Accent = Color(0xFFD71921)
private val Surface2 = Color(0xFF2C2C2E)

/**
 * Rendered at the *target* form's fixed size and clipped by the animated container,
 * so layout never re-runs while the shape springs.
 */
@Composable
fun IslandContent(
    state: IslandState,
    geometry: IslandGeometry,
    alpha: () -> Float,
    actions: IslandActions,
) {
    if (state is IslandState.Idle) return
    val form = state.form
    Box(
        Modifier
            .requiredSize(geometry.widthOf(form).dp, geometry.heightOf(form).dp)
            .graphicsLayer { this.alpha = alpha() },
    ) {
        when (state) {
            IslandState.Idle -> Unit
            is IslandState.Compact -> CompactContent(state, geometry)
            is IslandState.Banner -> BannerContent(state.primary, geometry, actions)
            is IslandState.Expanded -> ExpandedMedia(state.primary, geometry, actions)
        }
    }
}

// ------------------------------------------------------------------ compact (leading / trailing)

@Composable
private fun CompactContent(state: IslandState.Compact, geometry: IslandGeometry) {
    val glyph = (geometry.idleH - 8f).coerceIn(14f, 24f).dp
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.weight(1f).fillMaxHeight().padding(start = 12.dp),
            contentAlignment = Alignment.CenterStart,
        ) { Leading(state.primary, glyph) }

        // The camera lives here.
        Spacer(Modifier.width(geometry.idleW.dp))

        Box(
            Modifier.weight(1f).fillMaxHeight().padding(end = 12.dp),
            contentAlignment = Alignment.CenterEnd,
        ) {
            val secondary = state.secondary
            if (secondary != null) Leading(secondary, glyph) else Trailing(state.primary, glyph)
        }
    }
}

@Composable
private fun Leading(activity: IslandActivity, size: Dp) {
    when (activity) {
        is MediaInfo -> ArtThumb(activity.art, size)
        is NotificationInfo -> ArtThumb(activity.appIcon, size)
        is CallInfo -> Icon(Glyphs.Call, contentDescription = null, tint = Green, modifier = Modifier.size(size))
        is ChargingInfo -> BatteryRing(activity.level, size)
    }
}

@Composable
private fun Trailing(activity: IslandActivity, size: Dp) {
    when (activity) {
        is MediaInfo -> Equalizer(activity.isPlaying, size)
        is CallInfo -> CallTimer(activity.startedAtWallClock, 12.sp, Green)
        is ChargingInfo -> Text(
            text = "${activity.level}%",
            color = Green,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            softWrap = false,
        )
        is NotificationInfo -> ArtThumb(activity.appIcon, size)
    }
}

// ------------------------------------------------------------------ banner (notification / call)

@Composable
private fun BannerContent(activity: IslandActivity, geometry: IslandGeometry, actions: IslandActions) {
    Row(
        Modifier
            .fillMaxSize()
            .padding(top = geometry.contentTop.dp, start = 16.dp, end = 16.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when (activity) {
            is NotificationInfo -> {
                ArtThumb(activity.appIcon, 40.dp, 10.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = activity.title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (activity.text.isNotEmpty()) {
                        Text(
                            text = activity.text,
                            color = Gray,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            is CallInfo -> CallBannerRow(activity, actions)
            else -> Unit
        }
    }
}

@Composable
private fun RowScope.CallBannerRow(call: CallInfo, actions: IslandActions) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Surface2),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = call.callerName.firstOrNull()?.uppercase() ?: "?",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
    Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)) {
        Text(
            text = call.callerName,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (call.isIncoming) {
            Text(text = "Incoming call", color = Gray, fontSize = 13.sp, maxLines = 1)
        } else {
            CallTimer(call.startedAtWallClock, 13.sp, Green)
        }
    }
    CircleButton(Red, iconRotation = 135f) { actions.decline(call) }
    if (call.isIncoming) {
        Spacer(Modifier.width(12.dp))
        CircleButton(Green, iconRotation = 0f) { actions.answer(call) }
    }
}

@Composable
private fun CircleButton(color: Color, iconRotation: Float, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Glyphs.Call,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(22.dp).graphicsLayer { rotationZ = iconRotation },
        )
    }
}

// ------------------------------------------------------------------ expanded media

@Composable
private fun ExpandedMedia(media: MediaInfo, geometry: IslandGeometry, actions: IslandActions) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(top = geometry.contentTop.dp, start = 18.dp, end = 18.dp, bottom = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ArtThumb(
                bitmap = media.art,
                size = 60.dp,
                corner = 14.dp,
                modifier = Modifier.clickable { actions.openApp(media.packageName) },
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = media.title.ifEmpty { "Unknown" },
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = media.artist,
                    color = Gray,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Equalizer(media.isPlaying, 22.dp)
        }
        Spacer(Modifier.height(10.dp))
        SeekSection(media, actions)
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ControlButton(Glyphs.Previous, 28.dp, media.canPrevious) { actions.previous() }
            ControlButton(if (media.isPlaying) Glyphs.Pause else Glyphs.Play, 36.dp, true) {
                actions.togglePlayPause(media)
            }
            ControlButton(Glyphs.Next, 28.dp, media.canNext) { actions.next() }
        }
    }
}

@Composable
private fun ControlButton(icon: ImageVector, iconSize: Dp, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) Color.White else Color(0x59FFFFFF),
            modifier = Modifier.size(iconSize),
        )
    }
}

@Composable
private fun SeekSection(media: MediaInfo, actions: IslandActions) {
    val positionMs = remember { mutableLongStateOf(0L) }
    LaunchedEffect(media.positionMs, media.positionUpdatedAtElapsed, media.isPlaying, media.speed, media.durationMs) {
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val raw = if (media.isPlaying) {
                media.positionMs + ((now - media.positionUpdatedAtElapsed) * media.speed).toLong()
            } else {
                media.positionMs
            }
            positionMs.longValue = if (media.durationMs > 0) raw.coerceIn(0L, media.durationMs) else raw.coerceAtLeast(0L)
            if (!media.isPlaying) break
            delay(100)
        }
    }
    val hasDuration = media.durationMs > 0
    val seekable = media.canSeek && hasDuration
    val latestDuration = rememberUpdatedState(media.durationMs)
    Column {
        SeekBar(
            progress = { if (hasDuration) positionMs.longValue.toFloat() / media.durationMs else 0f },
            enabled = seekable,
            onSeek = { fraction -> actions.seekTo((fraction * latestDuration.value).toLong()) },
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TimeText(positionMs = { positionMs.longValue })
            Text(
                text = if (hasDuration) formatDuration(media.durationMs) else "--:--",
                color = Gray,
                fontSize = 11.sp,
            )
        }
    }
}

/** Only this tiny composable recomposes (once per second) while a track plays. */
@Composable
private fun TimeText(positionMs: () -> Long) {
    val source = rememberUpdatedState(positionMs)
    val seconds by remember { derivedStateOf { source.value.invoke() / 1000L } }
    Text(text = formatDuration(seconds * 1000L), color = Gray, fontSize = 11.sp)
}

@Composable
private fun SeekBar(progress: () -> Float, enabled: Boolean, onSeek: (Float) -> Unit) {
    val dragFraction = remember { mutableFloatStateOf(-1f) }
    val currentOnSeek = rememberUpdatedState(onSeek)
    val currentEnabled = rememberUpdatedState(enabled)
    val density = LocalDensity.current
    val trackHeight = with(density) { 5.dp.toPx() }
    val thumbRadius = with(density) { 6.dp.toPx() }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(22.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    if (currentEnabled.value) currentOnSeek.value((offset.x / size.width).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        if (currentEnabled.value) dragFraction.floatValue = (offset.x / size.width).coerceIn(0f, 1f)
                    },
                    onDragEnd = {
                        val f = dragFraction.floatValue
                        if (f >= 0f) currentOnSeek.value(f)
                        dragFraction.floatValue = -1f
                    },
                    onDragCancel = { dragFraction.floatValue = -1f },
                ) { change, _ ->
                    change.consume()
                    if (currentEnabled.value) {
                        dragFraction.floatValue = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                }
            },
    ) {
        val fraction = if (dragFraction.floatValue >= 0f) dragFraction.floatValue else progress().coerceIn(0f, 1f)
        val cy = size.height / 2f
        val left = thumbRadius
        val width = size.width - thumbRadius * 2f
        drawRoundRect(
            color = Color(0x33FFFFFF),
            topLeft = Offset(left, cy - trackHeight / 2f),
            size = Size(width, trackHeight),
            cornerRadius = CornerRadius(trackHeight / 2f),
        )
        drawRoundRect(
            color = if (enabled) Color.White else Color(0x66FFFFFF),
            topLeft = Offset(left, cy - trackHeight / 2f),
            size = Size(width * fraction, trackHeight),
            cornerRadius = CornerRadius(trackHeight / 2f),
        )
        if (enabled) {
            drawCircle(Color.White, thumbRadius, Offset(left + width * fraction, cy))
        }
    }
}

// ------------------------------------------------------------------ small pieces

@Composable
private fun ArtThumb(
    bitmap: ImageBitmap?,
    size: Dp,
    corner: Dp = size / 4,
    modifier: Modifier = Modifier,
) {
    val base = modifier.size(size).clip(RoundedCornerShape(corner))
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = base, contentScale = ContentScale.Crop)
    } else {
        Box(base.background(Surface2), contentAlignment = Alignment.Center) {
            Text(text = "\u266A", color = Gray, fontSize = (size.value * 0.55f).sp)
        }
    }
}

@Composable
private fun Equalizer(playing: Boolean, dim: Dp) {
    val phase: State<Float> = if (playing) {
        val transition = rememberInfiniteTransition(label = "eq")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = (2.0 * PI).toFloat(),
            animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
            label = "eqPhase",
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }
    val amplitude = animateFloatAsState(
        targetValue = if (playing) 1f else 0f,
        animationSpec = spring(stiffness = 200f),
        label = "eqAmp",
    )
    Canvas(Modifier.size(dim)) {
        val bars = 4
        val barW = size.width / (bars * 2 - 1)
        val h = size.height
        for (i in 0 until bars) {
            val k = 0.5f + 0.5f * sin(phase.value * (1f + 0.31f * i) + i * 1.9f)
            val fraction = 0.25f + 0.75f * k * amplitude.value
            val barH = h * fraction
            drawRoundRect(
                color = Accent,
                topLeft = Offset(i * 2 * barW, (h - barH) / 2f),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW / 2f),
            )
        }
    }
}

@Composable
private fun BatteryRing(level: Int, dim: Dp) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(level) { progress.animateTo(level / 100f, spring(stiffness = 120f)) }
    val strokePx = with(LocalDensity.current) { 2.5.dp.toPx() }
    val track = remember(strokePx) { Stroke(width = strokePx) }
    val arc = remember(strokePx) { Stroke(width = strokePx, cap = StrokeCap.Round) }
    Canvas(Modifier.size(dim)) {
        val inset = strokePx / 2f
        val d = size.minDimension - strokePx
        drawArc(Color(0x33FFFFFF), 0f, 360f, false, Offset(inset, inset), Size(d, d), style = track)
        drawArc(Green, -90f, 360f * progress.value, false, Offset(inset, inset), Size(d, d), style = arc)
    }
}

@Composable
private fun CallTimer(startedAt: Long, fontSize: TextUnit, color: Color) {
    var seconds by remember(startedAt) { mutableLongStateOf(elapsedSeconds(startedAt)) }
    LaunchedEffect(startedAt) {
        while (true) {
            seconds = elapsedSeconds(startedAt)
            delay(1000L - ((System.currentTimeMillis() - startedAt) % 1000L))
        }
    }
    Text(
        text = formatDuration(seconds * 1000L),
        color = color,
        fontSize = fontSize,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
        softWrap = false,
    )
}

private fun elapsedSeconds(startedAt: Long): Long =
    ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(0L)

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
