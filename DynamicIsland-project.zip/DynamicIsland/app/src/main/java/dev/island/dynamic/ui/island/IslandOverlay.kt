package dev.island.dynamic.ui.island

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import dev.island.dynamic.model.IslandActions
import dev.island.dynamic.model.IslandForm
import dev.island.dynamic.model.IslandState
import dev.island.dynamic.model.form
import dev.island.dynamic.settings.IslandSettings
import dev.island.dynamic.system.IslandGeometry
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.min

@Composable
fun IslandOverlay(
    stateFlow: StateFlow<IslandState>,
    settingsFlow: StateFlow<IslandSettings>,
    geometryFlow: StateFlow<IslandGeometry>,
    visibleFlow: StateFlow<Boolean>,
    actions: IslandActions,
) {
    val visible by visibleFlow.collectAsState()
    // When hidden nothing is composed, so no animation can keep the GPU busy.
    if (!visible) return
    val state by stateFlow.collectAsState()
    val settings by settingsFlow.collectAsState()
    val geometry by geometryFlow.collectAsState()
    MaterialTheme(colorScheme = darkColorScheme()) {
        IslandSurface(state, settings, geometry, actions)
    }
}

private data class ContentKey(val form: IslandForm, val a: String, val b: String?)

private fun IslandState.contentKey(): ContentKey = when (this) {
    IslandState.Idle -> ContentKey(IslandForm.Idle, "", null)
    is IslandState.Compact -> ContentKey(IslandForm.Compact, primary.id, secondary?.id)
    is IslandState.Banner -> ContentKey(IslandForm.Banner, primary.id, null)
    is IslandState.Expanded -> ContentKey(IslandForm.Expanded, primary.id, null)
}

private class KeyHolder(var key: ContentKey)

private fun inPill(offset: Offset, windowWidthPx: Int, shape: IslandShape): Boolean {
    val left = (windowWidthPx - shape.width) / 2f
    return offset.x >= left && offset.x <= left + shape.width && offset.y >= 0f && offset.y <= shape.height
}

@Composable
private fun IslandSurface(
    state: IslandState,
    settings: IslandSettings,
    geometry: IslandGeometry,
    actions: IslandActions,
) {
    val density = LocalDensity.current
    val speed = settings.animSpeed
    val form = state.form

    // ---- one shared transition state: width, height and radius spring together ----
    val target = remember(form, geometry, settings.cornerRadiusDp, density) {
        with(density) {
            val w = geometry.widthOf(form).dp.toPx()
            val h = geometry.heightOf(form).dp.toPx()
            val r = if (form == IslandForm.Idle || form == IslandForm.Compact) {
                h / 2f
            } else {
                min(settings.cornerRadiusDp.dp.toPx(), h / 2f)
            }
            IslandShape(w, h, r)
        }
    }
    val shape = remember { Animatable(target, IslandShapeConverter) }
    LaunchedEffect(target, speed) {
        // animateTo from an in-flight animation keeps the current value AND velocity.
        shape.animateTo(target, IslandSpring.shape(speed))
    }

    // ---- staggered content: container first, content ~80ms later; fade out first on change ----
    val contentAlpha = remember { Animatable(0f) }
    val displayed = remember { mutableStateOf<IslandState>(IslandState.Idle) }
    val holder = remember { KeyHolder(IslandState.Idle.contentKey()) }
    val speedState = rememberUpdatedState(speed)
    LaunchedEffect(state) {
        val key = state.contentKey()
        val s = speedState.value
        if (key != holder.key) {
            if (contentAlpha.value > 0.01f) contentAlpha.animateTo(0f, IslandSpring.fadeOut(s))
            displayed.value = state
            holder.key = key
            if (state !is IslandState.Idle) {
                delay((IslandSpring.STAGGER_MS / s).toLong())
                contentAlpha.animateTo(1f, IslandSpring.fadeIn(s))
            }
        } else {
            // Same layout, new data (e.g. play/pause, position): update in place, no flicker.
            displayed.value = state
            if (state !is IslandState.Idle && contentAlpha.value < 1f) {
                contentAlpha.animateTo(1f, IslandSpring.fadeIn(s))
            }
        }
    }

    val pillColor = remember(settings.colorArgb) { Color(settings.colorArgb) }
    val clipPath = remember { Path() }
    val nativeClip = remember(clipPath) { clipPath.asAndroidPath() }
    val currentState by rememberUpdatedState(state)
    val currentActions by rememberUpdatedState(actions)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        if (inPill(offset, size.width, shape.value)) currentActions.onTap(currentState)
                    },
                    onLongPress = { offset ->
                        if (inPill(offset, size.width, shape.value)) currentActions.onLongPress(currentState)
                    },
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (abs(total) > 36.dp.toPx()) currentActions.onSwipe(if (total < 0f) 1 else -1)
                        total = 0f
                    },
                    onDragCancel = { total = 0f },
                ) { change, dragAmount ->
                    total += dragAmount
                    change.consume()
                }
            }
            // Everything animated is read inside this draw lambda: no recomposition per frame.
            .drawWithContent {
                val s = shape.value
                val w = s.width
                val h = s.height
                val r = s.radius.coerceIn(0f, min(w, h) / 2f)
                val left = (size.width - w) / 2f
                drawRoundRect(
                    color = pillColor,
                    topLeft = Offset(left, 0f),
                    size = Size(w, h),
                    cornerRadius = CornerRadius(r, r),
                )
                nativeClip.rewind()
                nativeClip.addRoundRect(left, 0f, left + w, h, r, r, android.graphics.Path.Direction.CW)
                clipPath(clipPath) { this@drawWithContent.drawContent() }
            },
        contentAlignment = Alignment.TopCenter,
    ) {
        IslandContent(
            state = displayed.value,
            geometry = geometry,
            alpha = { contentAlpha.value },
            actions = currentActions,
        )
    }
}
