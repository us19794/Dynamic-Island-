package dev.island.dynamic

import android.app.Application
import android.content.Context
import dev.island.dynamic.model.IslandStateMachine
import dev.island.dynamic.settings.IslandSettings
import dev.island.dynamic.settings.SettingsRepository
import dev.island.dynamic.system.IslandController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow

class IslandApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}

/**
 * Process-wide singletons. Application.onCreate always runs before any service,
 * receiver or activity, including after process death, so these are always initialised.
 */
object ServiceLocator {
    lateinit var appContext: Context
        private set
    lateinit var repo: SettingsRepository
        private set
    lateinit var machine: IslandStateMachine
        private set
    lateinit var controller: IslandController
        private set

    val appScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings: StateFlow<IslandSettings> get() = repo.settings

    fun init(app: Application) {
        appContext = app.applicationContext
        repo = SettingsRepository(appContext, appScope)
        machine = IslandStateMachine(appScope, repo.settings)
        controller = IslandController(appContext, machine, repo.settings)
    }
}
