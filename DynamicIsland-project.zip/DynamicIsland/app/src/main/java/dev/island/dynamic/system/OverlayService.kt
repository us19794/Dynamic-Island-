package dev.island.dynamic.system

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.app.KeyguardManager
import android.service.notification.NotificationListenerService
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import dev.island.dynamic.MainActivity
import dev.island.dynamic.R
import dev.island.dynamic.ServiceLocator
import dev.island.dynamic.model.IslandEvent
import dev.island.dynamic.model.IslandForm
import dev.island.dynamic.model.NameDropBus
import dev.island.dynamic.model.NameDropRequest
import dev.island.dynamic.model.form
import dev.island.dynamic.ui.IslandTheme
import dev.island.dynamic.ui.island.IslandOverlay
import dev.island.dynamic.ui.namedrop.NameDropHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Hosts the island in a TYPE_APPLICATION_OVERLAY window.
 *
 * The window is always sized to the pill's current (or about to be) form plus a small margin,
 * so it never blocks touches on a large area. It grows before the spring starts and shrinks
 * only after the spring has had time to settle.
 */
class OverlayService : Service() {

    private data class Suppression(
        val wrongOrientation: Boolean = false,
        val locked: Boolean = false,
        val insetsFullscreen: Boolean = false,
    )

    private data class WindowTarget(val form: IslandForm, val geometry: dev.island.dynamic.system.IslandGeometry)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owner = OverlayLifecycleOwner()
    private val geometry = MutableStateFlow(IslandGeometry.Default)
    private val suppression = MutableStateFlow(Suppression())
    private val visible = MutableStateFlow(true)

    private lateinit var wm: WindowManager
    private lateinit var displayManager: DisplayManager
    private lateinit var params: WindowManager.LayoutParams

    private var view: ComposeView? = null
    private var attached = false
    private var jobsStarted = false
    private var density = 1f
    private var appliedW = 0f
    private var appliedH = 0f
    private var statusBarSeenVisible = false
    private var wasPlugged: Boolean? = null
    private var lastPercent = -1
    private var touchable = true

    // NameDrop: a second, full-screen window that exists only while the animation is on screen.
    private val mainHandler = Handler(Looper.getMainLooper())
    private var dropView: ComposeView? = null
    private var dropParams: WindowManager.LayoutParams? = null
    private var dropAttached = false
    private var dropFallbackJob: Job? = null
    private var blurAnimator: ValueAnimator? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF, Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    suppression.update { it.copy(locked = isLocked()) }
                    ensureOverlay()
                }
                Intent.ACTION_BATTERY_CHANGED -> onBattery(intent)
            }
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) refreshEnvironment()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(DisplayManager::class.java)
        density = resources.displayMetrics.density
        owner.create()
        params = buildParams()
        createChannel()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        val sticky = ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        if (sticky != null) initBattery(sticky)

        displayManager.registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))
        refreshEnvironment()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground(missingPermission = !Permissions.hasOverlay(this))
        ensureOverlay()
        startJobs()
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        removeNameDrop(force = true)
        detach()
        runCatching { unregisterReceiver(receiver) }
        runCatching { displayManager.unregisterDisplayListener(displayListener) }
        owner.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- jobs

    private fun startJobs() {
        if (jobsStarted) return
        jobsStarted = true

        scope.launch {
            ServiceLocator.settings.collect {
                recomputeGeometry()
            }
        }
        scope.launch {
            combine(ServiceLocator.machine.state, geometry) { st, g -> WindowTarget(st.form, g) }
                .collectLatest { t ->
                    val tw = t.geometry.widthOf(t.form)
                    val th = t.geometry.heightOf(t.form)
                    val bigW = max(appliedW, tw)
                    val bigH = max(appliedH, th)
                    applyWindow(t.geometry, bigW, bigH)
                    if (bigW != tw || bigH != th) {
                        delay(SHRINK_DELAY_MS)
                        applyWindow(t.geometry, tw, th)
                    }
                }
        }
        scope.launch {
            combine(suppression, OverlayBus.a11yFullscreen, ServiceLocator.settings) { s, a11y, st ->
                val hideForFullscreen = st.hideInFullscreen && (s.insetsFullscreen || a11y)
                !(s.wrongOrientation || s.locked || hideForFullscreen)
            }.collect { isVisible ->
                visible.value = isVisible
                setTouchable(isVisible)
            }
        }
        scope.launch {
            NameDropBus.request.collect { request ->
                if (request == null) hideNameDrop() else showNameDrop(request)
            }
        }
        // Permissions can be revoked at runtime and OEMs kill listeners; re-check periodically.
        scope.launch {
            while (isActive) {
                delay(15_000)
                ensureOverlay()
                ensureListenerBound()
            }
        }
    }

    // ---------------------------------------------------------------- overlay window

    private fun ensureOverlay() {
        if (!Permissions.hasOverlay(this)) {
            if (attached) detach()
            removeNameDrop(force = true)
            notifyForeground(missingPermission = true)
            return
        }
        notifyForeground(missingPermission = false)
        if (attached) return

        val g = geometry.value
        val form = ServiceLocator.machine.state.value.form
        applyWindow(g, g.widthOf(form), g.heightOf(form))

        val cv = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                IslandOverlay(
                    stateFlow = ServiceLocator.machine.state,
                    settingsFlow = ServiceLocator.settings,
                    geometryFlow = geometry,
                    visibleFlow = visible,
                    actions = ServiceLocator.controller,
                )
            }
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    ServiceLocator.controller.onOutsideTouch()
                }
                false
            }
            setOnApplyWindowInsetsListener { _, insets ->
                onInsets(insets)
                insets
            }
        }
        try {
            wm.addView(cv, params)
            view = cv
            attached = true
            owner.resume()
        } catch (e: Exception) {
            Log.e(TAG, "addView failed", e)
            runCatching { cv.disposeComposition() }
        }
    }

    private fun detach() {
        val v = view ?: return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
        runCatching { v.disposeComposition() }
        view = null
        attached = false
        appliedW = 0f
        appliedH = 0f
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            1,
            1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.title = "DynamicIsland"
        p.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 30) p.fitInsetsTypes = 0
        applyMaxRefreshRate(p)
        return p
    }

    /** Ask for the highest refresh rate at the current resolution. */
    private fun applyMaxRefreshRate(p: WindowManager.LayoutParams) {
        try {
            val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY) ?: return
            val current = display.mode
            val best = display.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            p.preferredDisplayModeId = best.modeId
            p.preferredRefreshRate = best.refreshRate
        } catch (e: Throwable) {
            Log.w(TAG, "refresh rate request failed", e)
        }
    }

    private fun applyWindow(g: IslandGeometry, w: Float, h: Float) {
        appliedW = w
        appliedH = h
        params.width = ((w + 2f * MARGIN_DP) * density).roundToInt()
        params.height = ((h + MARGIN_DP) * density).roundToInt()
        params.x = (g.xOffsetDp * density).roundToInt()
        params.y = (g.topDp * density).roundToInt()
        pushParams()
    }

    private fun setTouchable(isTouchable: Boolean) {
        if (touchable == isTouchable) return
        touchable = isTouchable
        params.flags = if (isTouchable) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        pushParams()
    }

    private fun pushParams() {
        val v = view ?: return
        if (!attached) return
        try {
            wm.updateViewLayout(v, params)
        } catch (e: Exception) {
            Log.w(TAG, "updateViewLayout failed", e)
            attached = false
        }
    }

    // ---------------------------------------------------------------- NameDrop window

    private fun showNameDrop(request: NameDropRequest) {
        val stale = SystemClock.elapsedRealtime() - request.createdAtElapsed > NAME_DROP_MAX_AGE_MS
        if (stale || !Permissions.hasOverlay(this) || suppression.value.locked) {
            NameDropBus.dismiss()
            return
        }
        dropFallbackJob?.cancel()
        if (dropAttached) {
            // Triggered again while the previous one was still leaving.
            setDropTouchable(true)
            animateDropBlur(blurRadiusPx())
            return
        }

        owner.resume()
        val cv = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                IslandTheme {
                    NameDropHost(
                        requestFlow = NameDropBus.request,
                        onDismiss = { NameDropBus.dismiss() },
                        onExited = { mainHandler.post { removeNameDrop() } },
                    )
                }
            }
        }
        val p = buildDropParams()
        try {
            wm.addView(cv, p)
            dropView = cv
            dropParams = p
            dropAttached = true
            animateDropBlur(blurRadiusPx())
        } catch (e: Exception) {
            Log.e(TAG, "NameDrop addView failed", e)
            runCatching { cv.disposeComposition() }
            NameDropBus.dismiss()
        }
    }

    /** Called when the request goes null: stop eating touches now, remove the window once it has animated out. */
    private fun hideNameDrop() {
        if (!dropAttached) return
        setDropTouchable(false)
        animateDropBlur(0)
        dropFallbackJob?.cancel()
        dropFallbackJob = scope.launch {
            delay(NAME_DROP_FALLBACK_MS) // safety net in case onExited never arrives
            removeNameDrop()
        }
    }

    private fun removeNameDrop(force: Boolean = false) {
        // A new request may have arrived while we were leaving; keep the window for it.
        if (!force && NameDropBus.request.value != null) return
        dropFallbackJob?.cancel()
        blurAnimator?.cancel()
        blurAnimator = null
        val v = dropView ?: return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
        runCatching { v.disposeComposition() }
        dropView = null
        dropParams = null
        dropAttached = false
    }

    private fun buildDropParams(): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        val blur = canBlurBehind()
        if (blur) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND

        // Full screen and touchable (no FLAG_NOT_TOUCHABLE) so taps outside the card can dismiss.
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.title = "DynamicIslandNameDrop"
        p.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 30) p.fitInsetsTypes = 0
        if (blur) p.blurBehindRadius = 0
        applyMaxRefreshRate(p)
        return p
    }

    private fun setDropTouchable(isTouchable: Boolean) {
        val p = dropParams ?: return
        p.flags = if (isTouchable) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        pushDropParams()
    }

    private fun canBlurBehind(): Boolean =
        Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled

    private fun blurRadiusPx(): Int = (NAME_DROP_BLUR_DP * density).roundToInt()

    /**
     * Blurs whatever is behind the window (the app underneath). Modifier.blur can't do this: it
     * only blurs a composable's own children. Needs Android 12+ and cross-window blur enabled on
     * the device; otherwise the scrim alone dims the screen.
     */
    private fun animateDropBlur(toRadius: Int) {
        val p = dropParams ?: return
        if (Build.VERSION.SDK_INT < 31) return
        if (p.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND == 0) return
        blurAnimator?.cancel()
        blurAnimator = ValueAnimator.ofInt(p.blurBehindRadius, toRadius).apply {
            duration = NAME_DROP_BLUR_MS
            addUpdateListener { animator ->
                p.blurBehindRadius = animator.animatedValue as Int
                pushDropParams()
            }
            start()
        }
    }

    private fun pushDropParams() {
        val v = dropView ?: return
        val p = dropParams ?: return
        if (!dropAttached) return
        try {
            wm.updateViewLayout(v, p)
        } catch (e: Exception) {
            Log.w(TAG, "NameDrop updateViewLayout failed", e)
        }
    }

    // ---------------------------------------------------------------- environment

    private fun refreshEnvironment() {
        density = resources.displayMetrics.density
        val rotation = displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
        suppression.update {
            it.copy(wrongOrientation = rotation != Surface.ROTATION_0, locked = isLocked())
        }
        recomputeGeometry()
    }

    private fun recomputeGeometry() {
        val dm = resources.displayMetrics
        if (dm.widthPixels > dm.heightPixels) return // landscape: island is hidden anyway
        geometry.value = GeometryCalculator.compute(
            dm.widthPixels,
            dm.density,
            readCutout(),
            ServiceLocator.settings.value,
        )
    }

    private fun readCutout(): Rect? {
        if (Build.VERSION.SDK_INT < 30) return null
        return try {
            val cutout = wm.currentWindowMetrics.windowInsets.displayCutout ?: return null
            val rect = cutout.boundingRectTop
            if (rect.isEmpty) null else Rect(rect)
        } catch (_: Throwable) {
            null
        }
    }

    private fun isLocked(): Boolean {
        val km = getSystemService(KeyguardManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        return (km?.isKeyguardLocked == true) || (pm?.isInteractive == false)
    }

    private fun onInsets(insets: WindowInsets) {
        if (Build.VERSION.SDK_INT < 30) return
        val statusVisible = insets.isVisible(WindowInsets.Type.statusBars())
        if (statusVisible) statusBarSeenVisible = true
        // Only trust "hidden" after we have seen "visible" at least once, so a device that never
        // reports bar visibility to overlay windows can't leave the island hidden forever.
        val fullscreen = statusBarSeenVisible && !statusVisible
        suppression.update { if (it.insetsFullscreen == fullscreen) it else it.copy(insetsFullscreen = fullscreen) }
    }

    private fun ensureListenerBound() {
        if (Permissions.hasNotificationAccess(this) && !IslandNotificationListener.connected) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, IslandNotificationListener::class.java),
                )
            } catch (_: Throwable) {
            }
        }
    }

    // ---------------------------------------------------------------- battery

    private fun initBattery(intent: Intent) {
        wasPlugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        lastPercent = percentOf(intent)
    }

    private fun percentOf(intent: Intent): Int {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level < 0 || scale <= 0) -1 else level * 100 / scale
    }

    private fun onBattery(intent: Intent) {
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val percent = percentOf(intent)
        if (percent < 0) return
        val previous = wasPlugged
        val just = plugged && previous == false
        if (previous == null || plugged != previous || percent != lastPercent) {
            ServiceLocator.machine.dispatch(IslandEvent.ChargingChanged(plugged, percent, just))
        }
        wasPlugged = plugged
        lastPercent = percent
    }

    // ---------------------------------------------------------------- foreground notification

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.channel_service), NotificationManager.IMPORTANCE_MIN),
        )
    }

    private fun buildNotification(missingPermission: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val title = if (missingPermission) R.string.service_missing_permission else R.string.service_running
        val text = if (missingPermission) R.string.service_missing_permission_text else R.string.service_running_text
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_island)
            .setContentTitle(getString(title))
            .setContentText(getString(text))
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun goForeground(missingPermission: Boolean) {
        val n = buildNotification(missingPermission)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
        lastNotifiedMissing = missingPermission
    }

    private var lastNotifiedMissing: Boolean? = null

    private fun notifyForeground(missingPermission: Boolean) {
        if (lastNotifiedMissing == missingPermission) return
        lastNotifiedMissing = missingPermission
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(missingPermission))
    }

    private companion object {
        const val TAG = "OverlayService"
        const val CHANNEL_ID = "island_service"
        const val NOTIFICATION_ID = 4101
        const val MARGIN_DP = 10f
        const val SHRINK_DELAY_MS = 750L
        const val NAME_DROP_MAX_AGE_MS = 3_000L
        const val NAME_DROP_FALLBACK_MS = 1_500L
        const val NAME_DROP_BLUR_DP = 20f
        const val NAME_DROP_BLUR_MS = 320L
    }
}
