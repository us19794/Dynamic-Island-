package dev.island.dynamic.model

import dev.island.dynamic.settings.IslandSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch

/**
 * Single source of truth. All events go through one channel and are reduced sequentially,
 * so the model never needs locks. Timers are just delayed events.
 */
class IslandStateMachine(
    private val scope: CoroutineScope,
    private val settings: StateFlow<IslandSettings>,
) {
    private val events = Channel<IslandEvent>(Channel.UNLIMITED)
    private val mutableState = MutableStateFlow<IslandState>(IslandState.Idle)
    val state: StateFlow<IslandState> = mutableState.asStateFlow()

    // Only touched from the reducer coroutine.
    private val activities = LinkedHashMap<String, IslandActivity>()
    private val timers = HashMap<String, Job>()
    private var selectedId: String? = null
    private var expandedFor: String? = null
    private var expandTimer: Job? = null

    init {
        scope.launch { for (event in events) reduce(event) }
        scope.launch { settings.drop(1).collect { events.trySend(IslandEvent.Refresh) } }
    }

    fun dispatch(event: IslandEvent) {
        events.trySend(event)
    }

    private fun reduce(event: IslandEvent) {
        when (event) {
            is IslandEvent.NotificationPosted -> {
                upsert(event.info)
                schedule(event.info.id, NOTIFICATION_MS, IslandEvent.NotificationExpired(event.info.id))
            }
            is IslandEvent.NotificationRemoved -> remove(event.id)
            is IslandEvent.NotificationExpired -> remove(event.id)
            is IslandEvent.MediaChanged -> {
                val info = event.info
                if (info == null) {
                    remove(MediaInfo.ID)
                } else {
                    upsert(info)
                    if (info.isPlaying) {
                        timers.remove(MediaInfo.ID)?.cancel()
                    } else {
                        schedule(MediaInfo.ID, MEDIA_PAUSED_MS, IslandEvent.MediaExpired)
                    }
                }
            }
            IslandEvent.MediaExpired -> remove(MediaInfo.ID)
            is IslandEvent.CallChanged -> {
                val info = event.info
                if (info == null) remove(CallInfo.ID) else upsert(info)
            }
            is IslandEvent.ChargingChanged -> {
                val existing = activities[ChargingInfo.ID]
                when {
                    !event.plugged -> remove(ChargingInfo.ID)
                    event.justPlugged -> {
                        upsert(ChargingInfo(event.level, System.currentTimeMillis()))
                        schedule(ChargingInfo.ID, CHARGING_MS, IslandEvent.ChargingExpired)
                    }
                    existing != null -> activities[ChargingInfo.ID] = ChargingInfo(event.level, existing.timestamp)
                }
            }
            IslandEvent.ChargingExpired -> remove(ChargingInfo.ID)
            IslandEvent.Expand -> {
                val primary = pickPrimary(visible())
                if (primary != null && isExpandable(primary)) {
                    expandedFor = primary.id
                    armExpandTimer()
                }
            }
            IslandEvent.Collapse -> {
                expandedFor = null
                expandTimer?.cancel()
            }
            is IslandEvent.Swipe -> {
                val list = visible()
                if (list.size > 1) {
                    val currentId = pickPrimary(list)?.id
                    val index = list.indexOfFirst { it.id == currentId }.coerceAtLeast(0)
                    val next = ((index + event.direction) % list.size + list.size) % list.size
                    selectedId = list[next].id
                    expandedFor = null
                }
            }
            IslandEvent.Interaction -> if (expandedFor != null) armExpandTimer()
            IslandEvent.ListenerDisconnected -> {
                val doomed = activities.values.filter { it !is ChargingInfo }.map { it.id }
                doomed.forEach { remove(it) }
            }
            IslandEvent.Refresh -> Unit
        }
        publish()
    }

    private fun upsert(activity: IslandActivity) {
        val isNew = !activities.containsKey(activity.id)
        activities[activity.id] = activity
        // A brand-new activity pre-empts a manual swipe selection.
        if (isNew) selectedId = null
    }

    private fun remove(id: String) {
        activities.remove(id)
        timers.remove(id)?.cancel()
        if (selectedId == id) selectedId = null
    }

    private fun schedule(key: String, delayMs: Long, event: IslandEvent) {
        timers.remove(key)?.cancel()
        timers[key] = scope.launch {
            delay(delayMs)
            events.trySend(event)
        }
    }

    private fun armExpandTimer() {
        expandTimer?.cancel()
        expandTimer = scope.launch {
            delay(EXPAND_TIMEOUT_MS)
            events.trySend(IslandEvent.Collapse)
        }
    }

    private fun visible(): List<IslandActivity> {
        val s = settings.value
        return activities.values
            .filter { s.allows(it) }
            .sortedWith(
                compareByDescending<IslandActivity> { it.priority }
                    .thenByDescending { it.timestamp },
            )
    }

    private fun pickPrimary(list: List<IslandActivity>): IslandActivity? {
        val id = selectedId
        return (if (id != null) list.firstOrNull { it.id == id } else null) ?: list.firstOrNull()
    }

    private fun isExpandable(a: IslandActivity): Boolean =
        a is MediaInfo || (a is CallInfo && !a.isIncoming)

    private fun publish() {
        val list = visible()
        val primary = pickPrimary(list)
        if (primary == null) {
            selectedId = null
            expandedFor = null
            mutableState.value = IslandState.Idle
            return
        }
        if (selectedId != null && selectedId != primary.id) selectedId = null
        val secondary = list.firstOrNull { it.id != primary.id }

        if (expandedFor != null && (expandedFor != primary.id || !isExpandable(primary))) {
            expandedFor = null
            expandTimer?.cancel()
        }
        val expanded = expandedFor == primary.id

        mutableState.value = when {
            primary is CallInfo && primary.isIncoming -> IslandState.Banner(primary)
            primary is NotificationInfo -> IslandState.Banner(primary)
            expanded && primary is MediaInfo -> IslandState.Expanded(primary)
            expanded && primary is CallInfo -> IslandState.Banner(primary)
            else -> IslandState.Compact(primary, secondary)
        }
    }

    private companion object {
        const val NOTIFICATION_MS = 4_000L
        const val CHARGING_MS = 3_500L
        const val MEDIA_PAUSED_MS = 30_000L
        const val EXPAND_TIMEOUT_MS = 8_000L
    }
}
