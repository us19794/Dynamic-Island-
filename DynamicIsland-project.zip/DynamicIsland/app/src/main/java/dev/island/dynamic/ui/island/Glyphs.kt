package dev.island.dynamic.ui.island

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** 24x24 icon paths so we don't need the large material-icons-extended dependency. */
object Glyphs {
    val Play = vector("play", "M8,5v14l11,-7z")
    val Pause = vector("pause", "M6,19h4V5H6v14zM14,5v14h4V5h-4z")
    val Next = vector("next", "M6,18l8.5,-6L6,6v12zM16,6v12h2V6h-2z")
    val Previous = vector("previous", "M6,6h2v12H6zM9.5,12l8.5,6V6z")
    val Call = vector(
        "call",
        "M6.62,10.79c1.44,2.83 3.76,5.14 6.59,6.59l2.2,-2.2c0.27,-0.27 0.67,-0.36 1.02,-0.24 " +
            "1.12,0.37 2.33,0.57 3.57,0.57 0.55,0 1,0.45 1,1V20c0,0.55 -0.45,1 -1,1 " +
            "-9.39,0 -17,-7.61 -17,-17 0,-0.55 0.45,-1 1,-1h3.5c0.55,0 1,0.45 1,1 " +
            "0,1.25 0.2,2.45 0.57,3.57 0.11,0.35 0.03,0.74 -0.25,1.02l-2.2,2.2z",
    )

    private fun vector(name: String, path: String): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = PathParser().parsePathString(path).toNodes(),
            fill = SolidColor(Color.Black),
        ).build()
}
