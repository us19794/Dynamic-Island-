package dev.island.dynamic.system

import android.content.Context
import android.os.SystemClock
import dev.island.dynamic.ServiceLocator
import dev.island.dynamic.model.CallInfo
import dev.island.dynamic.model.IslandEvent
import dev.island.dynamic.model.MediaInfo
import dev.island.dynamic.model.NotificationInfo

/** Fake events so animations can be previewed without waiting for real ones. */
object DemoEvents {
    private val machine get() = ServiceLocator.machine

    fun notification(context: Context) {
        val now = System.currentTimeMillis()
        machine.dispatch(
            IslandEvent.NotificationPosted(
                NotificationInfo(
                    id = "demo:$now",
                    packageName = context.packageName,
                    appIcon = AppIcons.get(context, context.packageName),
                    title = "Alex Rivera",
                    text = "Are we still on for 7? I just booked the table.",
                    contentIntent = null,
                    timestamp = now,
                ),
            ),
        )
    }

    fun media(context: Context) {
        machine.dispatch(
            IslandEvent.MediaChanged(
                MediaInfo(
                    packageName = context.packageName,
                    title = "Midnight City",
                    artist = "Demo Artist",
                    art = null,
                    isPlaying = true,
                    positionMs = 62_000L,
                    positionUpdatedAtElapsed = SystemClock.elapsedRealtime(),
                    speed = 1f,
                    durationMs = 243_000L,
                    canSeek = true,
                    canNext = true,
                    canPrevious = true,
                ),
            ),
        )
    }

    fun incomingCall(context: Context) {
        machine.dispatch(
            IslandEvent.CallChanged(
                CallInfo("Jamie Chen", true, System.currentTimeMillis(), null, null, null, context.packageName, null),
            ),
        )
    }

    fun ongoingCall(context: Context) {
        machine.dispatch(
            IslandEvent.CallChanged(
                CallInfo("Jamie Chen", false, System.currentTimeMillis(), null, null, null, context.packageName, null),
            ),
        )
    }

    fun charging() {
        machine.dispatch(IslandEvent.ChargingChanged(plugged = true, level = 72, justPlugged = true))
    }

    fun clear() {
        machine.dispatch(IslandEvent.MediaChanged(null))
        machine.dispatch(IslandEvent.CallChanged(null))
        machine.dispatch(IslandEvent.ChargingChanged(plugged = false, level = 0, justPlugged = false))
    }
}
