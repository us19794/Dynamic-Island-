package dev.island.dynamic.system

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import dev.island.dynamic.ServiceLocator
import dev.island.dynamic.model.CallInfo
import dev.island.dynamic.model.IslandEvent
import dev.island.dynamic.model.NotificationInfo

class IslandNotificationListener : NotificationListenerService() {

    private var media: MediaMonitor? = null
    private var callKey: String? = null
    private var callStartMs = 0L
    private val seen = HashMap<String, Int>()

    override fun onListenerConnected() {
        connected = true
        media = MediaMonitor(applicationContext, ComponentName(this, IslandNotificationListener::class.java)).also { it.start() }
        // Pick up a call that is already in progress (e.g. after process death).
        try {
            activeNotifications?.forEach { handle(it, initial = true) }
        } catch (_: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        connected = false
        media?.stop()
        media = null
        callKey = null
        seen.clear()
        ServiceLocator.machine.dispatch(IslandEvent.ListenerDisconnected)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        handle(sbn, initial = false)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seen.remove(sbn.key)
        ServiceLocator.machine.dispatch(IslandEvent.NotificationRemoved("n:${sbn.key}"))
        if (sbn.key == callKey) {
            callKey = null
            callStartMs = 0L
            ServiceLocator.machine.dispatch(IslandEvent.CallChanged(null))
        }
    }

    private fun handle(sbn: StatusBarNotification, initial: Boolean) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        val extras = n.extras

        val isCall = n.category == Notification.CATEGORY_CALL || extras.getInt(EXTRA_CALL_TYPE, 0) != 0
        if (isCall) {
            handleCall(sbn, n)
            return
        }
        if (initial) return

        if (pkg in ServiceLocator.settings.value.disabledApps) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS -> return
        }

        // Skip silent notifications.
        try {
            val ranking = Ranking()
            if (currentRanking?.getRanking(sbn.key, ranking) == true &&
                ranking.importance < android.app.NotificationManager.IMPORTANCE_DEFAULT
            ) return
        } catch (_: Throwable) {
        }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val signature = (title + "\u0000" + text).hashCode()
        if (seen[sbn.key] == signature) return
        seen[sbn.key] = signature

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }
        ServiceLocator.machine.dispatch(
            IslandEvent.NotificationPosted(
                NotificationInfo(
                    id = "n:${sbn.key}",
                    packageName = pkg,
                    appIcon = AppIcons.get(applicationContext, pkg),
                    title = title.ifBlank { label },
                    text = text,
                    contentIntent = n.contentIntent,
                    timestamp = System.currentTimeMillis(),
                ),
            ),
        )
    }

    private fun handleCall(sbn: StatusBarNotification, n: Notification) {
        val extras = n.extras
        val type = extras.getInt(EXTRA_CALL_TYPE, 0)
        // 1 = incoming, 2 = ongoing, 3 = screening (CallStyle). Fall back to fullScreenIntent for legacy styles.
        val incoming = type == 1 || type == 3 || (type == 0 && n.fullScreenIntent != null)
        val name = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().ifBlank { "Unknown caller" }
        val actions = n.actions.orEmpty()

        var answer: PendingIntent? = null
        var decline: PendingIntent? = null
        if (incoming) {
            decline = actions.firstOrNull { it.titleLower().matchesAny(DECLINE_WORDS) }?.actionIntent
            answer = actions.firstOrNull { it.titleLower().matchesAny(ANSWER_WORDS) }?.actionIntent
            if (answer == null && decline == null && actions.size >= 2) {
                // CallStyle.forIncomingCall puts decline first, answer second.
                decline = actions[0].actionIntent
                answer = actions[1].actionIntent
            }
        } else {
            decline = actions.lastOrNull()?.actionIntent // hang up
        }

        val now = System.currentTimeMillis()
        val startedAt = if (incoming) {
            callStartMs = 0L
            now
        } else {
            if (callStartMs == 0L) {
                val chronoWhen = n.`when`
                callStartMs = if (extras.getBoolean(EXTRA_SHOW_CHRONOMETER) && chronoWhen in 1..now) chronoWhen else now
            }
            callStartMs
        }

        callKey = sbn.key
        ServiceLocator.machine.dispatch(
            IslandEvent.CallChanged(
                CallInfo(
                    callerName = name,
                    isIncoming = incoming,
                    startedAtWallClock = startedAt,
                    answerIntent = answer,
                    declineIntent = decline,
                    contentIntent = n.contentIntent,
                    packageName = sbn.packageName,
                    appIcon = AppIcons.get(applicationContext, sbn.packageName),
                ),
            ),
        )
    }

    private fun Notification.Action.titleLower(): String = title?.toString()?.lowercase().orEmpty()

    private fun String.matchesAny(words: List<String>): Boolean = words.any { contains(it) }

    companion object {
        @Volatile
        var connected = false
            private set

        private const val EXTRA_CALL_TYPE = "android.callType"
        private const val EXTRA_SHOW_CHRONOMETER = "android.showChronometer"
        private val DECLINE_WORDS = listOf("decline", "reject", "dismiss", "hang up", "hangup")
        private val ANSWER_WORDS = listOf("answer", "accept", "pick up")
    }
}
