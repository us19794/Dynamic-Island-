package dev.island.dynamic.system

import android.graphics.Rect
import androidx.compose.runtime.Immutable
import dev.island.dynamic.model.IslandForm
import dev.island.dynamic.settings.IslandSettings
import kotlin.math.max
import kotlin.math.min

/** All values in dp. Window and Compose both derive their sizes from this. */
@Immutable
data class IslandGeometry(
    val idleW: Float,
    val idleH: Float,
    val compactW: Float,
    val bannerW: Float,
    val bannerH: Float,
    val expandedW: Float,
    val expandedH: Float,
    /** Pill top, from the top of the display. */
    val topDp: Float,
    /** Pill centre relative to the display centre. */
    val xOffsetDp: Float,
) {
    /** Content of banner/expanded forms starts just below the camera zone. */
    val contentTop: Float get() = idleH + 2f

    fun widthOf(form: IslandForm): Float = when (form) {
        IslandForm.Idle -> idleW
        IslandForm.Compact -> compactW
        IslandForm.Banner -> bannerW
        IslandForm.Expanded -> expandedW
    }

    fun heightOf(form: IslandForm): Float = when (form) {
        IslandForm.Idle -> idleH
        IslandForm.Compact -> idleH
        IslandForm.Banner -> bannerH
        IslandForm.Expanded -> expandedH
    }

    companion object {
        val Default = IslandGeometry(56f, 26f, 144f, 360f, 98f, 360f, 204f, 8f, 0f)
    }
}

object GeometryCalculator {
    private const val SIDE_W = 44f

    /** [cutoutPx] is the top cutout bounding rect in display pixels, or null. */
    fun compute(screenWidthPx: Int, density: Float, cutoutPx: Rect?, s: IslandSettings): IslandGeometry {
        val screenW = screenWidthPx / density
        val cutout = if (s.autoAlign && cutoutPx != null && !cutoutPx.isEmpty) cutoutPx else null

        val idleW: Float
        val idleH: Float
        val baseTop: Float
        val baseCenterX: Float
        if (cutout != null) {
            idleW = max(s.widthDp, cutout.width() / density + 14f)
            idleH = max(s.heightDp, cutout.height() / density + 8f)
            baseTop = cutout.exactCenterY() / density - idleH / 2f
            baseCenterX = cutout.exactCenterX() / density
        } else {
            idleW = s.widthDp
            idleH = s.heightDp
            baseTop = 8f
            baseCenterX = screenW / 2f
        }

        val compactW = min(idleW + 2f * SIDE_W, screenW - 8f)
        val bigW = max(min(screenW - 24f, 372f), compactW)

        return IslandGeometry(
            idleW = idleW,
            idleH = idleH,
            compactW = compactW,
            bannerW = bigW,
            bannerH = idleH + 72f,
            expandedW = bigW,
            expandedH = idleH + 178f,
            topDp = baseTop + s.offsetYDp,
            xOffsetDp = (baseCenterX - screenW / 2f) + s.offsetXDp,
        )
    }
}
