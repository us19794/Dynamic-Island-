package dev.island.dynamic.system

import kotlinx.coroutines.flow.MutableStateFlow

/** Cross-service signals that don't belong in the island state machine. */
object OverlayBus {
    /** Set by the optional AccessibilityService. */
    val a11yFullscreen = MutableStateFlow(false)
}
