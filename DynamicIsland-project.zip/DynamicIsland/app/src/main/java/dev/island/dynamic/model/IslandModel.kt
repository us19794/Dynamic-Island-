package dev.island.dynamic.model

import android.app.PendingIntent
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

/** Higher number wins the primary slot. */
object Priority {
    const val CALL = 100
    const val NOTIFICATION = 60
    const val CHARGING = 50
    const val MEDIA = 10
}

sealed interface IslandActivity {
    val id: String
    val priority: Int
    val timestamp: Long
}

@Immutable
data class NotificationInfo(
    override val id: String,
    val packageName: String,
    val appIcon: ImageBitmap?,
    val title: String,
    val text: String,
    val contentIntent: PendingIntent?,
    override val timestamp: Long,
) : IslandActivity {
    override val priority: Int get() = Priority.NOTIFICATION
}

@Immutable
data class MediaInfo(
    val packageName: String,
    val title: String,
    val artist: String,
    val art: ImageBitmap?,
    val isPlaying: Boolean,
    val positionMs: Long,
    val positionUpdatedAtElapsed: Long,
    val speed: Float,
    val durationMs: Long,
    val canSeek: Boolean,
    val canNext: Boolean,
    val canPrevious: Boolean,
) : IslandActivity {
    override val id: String get() = ID
    override val priority: Int get() = Priority.MEDIA
    override val timestamp: Long get() = 0L

    companion object {
        const val ID = "media"
    }
}

@Immutable
data class CallInfo(
    val callerName: String,
    val isIncoming: Boolean,
    val startedAtWallClock: Long,
    val answerIntent: PendingIntent?,
    /** Decline for incoming calls, hang-up for ongoing calls. */
    val declineIntent: PendingIntent?,
    val contentIntent: PendingIntent?,
    val packageName: String,
    val appIcon: ImageBitmap?,
) : IslandActivity {
    override val id: String get() = ID
    override val priority: Int get() = Priority.CALL
    override val timestamp: Long get() = startedAtWallClock

    companion object {
        const val ID = "call"
    }
}

@Immutable
data class ChargingInfo(
    val level: Int,
    override val timestamp: Long,
) : IslandActivity {
    override val id: String get() = ID
    override val priority: Int get() = Priority.CHARGING

    companion object {
        const val ID = "charging"
    }
}

enum class IslandForm { Idle, Compact, Banner, Expanded }

/** UI is a pure function of this. */
sealed interface IslandState {
    @Immutable
    data object Idle : IslandState

    /** Leading/trailing layout. [secondary] is the next activity by priority, if any. */
    @Immutable
    data class Compact(val primary: IslandActivity, val secondary: IslandActivity?) : IslandState

    /** Notification, incoming call, or an expanded ongoing call. */
    @Immutable
    data class Banner(val primary: IslandActivity) : IslandState

    /** Full media controls. */
    @Immutable
    data class Expanded(val primary: MediaInfo) : IslandState
}

val IslandState.form: IslandForm
    get() = when (this) {
        IslandState.Idle -> IslandForm.Idle
        is IslandState.Compact -> IslandForm.Compact
        is IslandState.Banner -> IslandForm.Banner
        is IslandState.Expanded -> IslandForm.Expanded
    }

sealed interface IslandEvent {
    data class NotificationPosted(val info: NotificationInfo) : IslandEvent
    data class NotificationRemoved(val id: String) : IslandEvent
    data class NotificationExpired(val id: String) : IslandEvent
    data class MediaChanged(val info: MediaInfo?) : IslandEvent
    data object MediaExpired : IslandEvent
    data class CallChanged(val info: CallInfo?) : IslandEvent
    data class ChargingChanged(val plugged: Boolean, val level: Int, val justPlugged: Boolean) : IslandEvent
    data object ChargingExpired : IslandEvent
    data object Expand : IslandEvent
    data object Collapse : IslandEvent
    data class Swipe(val direction: Int) : IslandEvent
    data object Interaction : IslandEvent
    data object ListenerDisconnected : IslandEvent
    data object Refresh : IslandEvent
}

/** Everything the UI can ask the system to do. Implemented by IslandController. */
interface IslandActions {
    fun onTap(state: IslandState)
    fun onLongPress(state: IslandState)
    fun onSwipe(direction: Int)
    fun onOutsideTouch()
    fun togglePlayPause(info: MediaInfo)
    fun next()
    fun previous()
    fun seekTo(positionMs: Long)
    fun answer(call: CallInfo)
    fun decline(call: CallInfo)
    fun openApp(packageName: String)
}
