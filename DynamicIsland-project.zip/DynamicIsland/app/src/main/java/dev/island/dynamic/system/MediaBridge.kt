package dev.island.dynamic.system

import android.media.session.MediaController

/** Holds the MediaController the island is currently following, for transport commands. */
object MediaBridge {
    @Volatile
    var controller: MediaController? = null
}
