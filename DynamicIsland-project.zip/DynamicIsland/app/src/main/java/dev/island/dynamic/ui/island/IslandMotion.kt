package dev.island.dynamic.ui.island

import androidx.compose.animation.core.AnimationVector3D
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.TwoWayConverter
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Immutable

/** One shared shape: width, height and corner radius (all px) animate as a single vector. */
@Immutable
data class IslandShape(val width: Float, val height: Float, val radius: Float)

val IslandShapeConverter: TwoWayConverter<IslandShape, AnimationVector3D> = TwoWayConverter(
    convertToVector = { AnimationVector3D(it.width, it.height, it.radius) },
    convertFromVector = { IslandShape(it.v1, it.v2, it.v3) },
)

/**
 * TUNING: these are the only numbers that define the feel.
 *
 * damping   < 1 overshoots a little (iOS-like). 0.70 is bouncy, 0.85 is calm, 1.0 is no overshoot.
 * stiffness higher = faster. 300-500 is the sweet spot.
 * The "Animation speed" setting multiplies stiffness by speed^2, which scales time by `speed`
 * without changing how bouncy it feels.
 */
object IslandSpring {
    const val DAMPING = 0.76f
    const val STIFFNESS = 420f

    const val FADE_IN_STIFFNESS = 260f
    const val FADE_OUT_STIFFNESS = 2000f

    /** Content appears this long after the container starts growing. */
    const val STAGGER_MS = 80L

    fun shape(speed: Float): FiniteAnimationSpec<IslandShape> =
        spring(dampingRatio = DAMPING, stiffness = STIFFNESS * speed * speed)

    fun fadeIn(speed: Float): FiniteAnimationSpec<Float> =
        spring(dampingRatio = 1f, stiffness = FADE_IN_STIFFNESS * speed * speed)

    fun fadeOut(speed: Float): FiniteAnimationSpec<Float> =
        spring(dampingRatio = 1f, stiffness = FADE_OUT_STIFFNESS * speed * speed)
}
