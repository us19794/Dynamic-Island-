package dev.island.dynamic.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.Preferences
import dev.island.dynamic.ServiceLocator
import dev.island.dynamic.model.NameDropBus
import dev.island.dynamic.startIslandIfPossible
import dev.island.dynamic.settings.Keys
import dev.island.dynamic.system.DemoEvents
import dev.island.dynamic.system.OverlayService
import kotlinx.coroutines.launch

private val Swatches = listOf(0xFF000000L, 0xFF1C1C1EL, 0xFF0A1A3AL, 0xFF0F2A1BL, 0xFF2A0F14L)

@Composable
fun SettingsScreen(onOpenApps: () -> Unit, onOpenSetup: () -> Unit) {
    val context = LocalContext.current
    val s by ServiceLocator.settings.collectAsState()
    val scope = rememberCoroutineScope()

    fun <T> save(key: Preferences.Key<T>, value: T) {
        scope.launch { ServiceLocator.repo.set(key, value) }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Island", style = MaterialTheme.typography.headlineMedium) }

            item {
                Section("Status") {
                    SwitchRow("Show island", s.serviceEnabled) { on ->
                        save(Keys.SERVICE_ENABLED, on)
                        val intent = Intent(context, OverlayService::class.java)
                        if (on) ContextCompat.startForegroundService(context, intent) else context.stopService(intent)
                    }
                    OutlinedButton(onClick = onOpenSetup, modifier = Modifier.fillMaxWidth()) {
                        Text("Review permissions and setup")
                    }
                }
            }

            item {
                Section("Preview") {
                    Text(
                        "Trigger fake events to see the animations. Long-pressing the idle island also starts NameDrop.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { DemoEvents.notification(context) }) { Text("Notif") }
                        Button(onClick = { DemoEvents.media(context) }) { Text("Media") }
                        Button(onClick = { DemoEvents.charging() }) { Text("Charge") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { DemoEvents.incomingCall(context) }) { Text("Ringing") }
                        Button(onClick = { DemoEvents.ongoingCall(context) }) { Text("In call") }
                        OutlinedButton(onClick = { DemoEvents.clear() }) { Text("Clear") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                startIslandIfPossible(context)
                                NameDropBus.show()
                            },
                        ) { Text("NameDrop") }
                    }
                }
            }

            item {
                Section("Activities") {
                    SwitchRow("Notifications", s.notificationsEnabled) { save(Keys.NOTIFICATIONS, it) }
                    SwitchRow("Media", s.mediaEnabled) { save(Keys.MEDIA, it) }
                    SwitchRow("Calls", s.callsEnabled) { save(Keys.CALLS, it) }
                    SwitchRow("Charging", s.chargingEnabled) { save(Keys.CHARGING, it) }
                    OutlinedButton(onClick = onOpenApps, modifier = Modifier.fillMaxWidth()) {
                        Text("Choose apps for notifications")
                    }
                }
            }

            item {
                Section("Position and size") {
                    SwitchRow("Align to camera cutout automatically", s.autoAlign) { save(Keys.AUTO_ALIGN, it) }
                    Text(
                        if (s.autoAlign) {
                            "Width and height act as minimums around the detected cutout. Offsets nudge the result."
                        } else {
                            "Manual mode: the island is centred at the top, shifted by the offsets below."
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                    SettingSlider("Width", s.widthDp, 24f..160f, "dp") { save(Keys.WIDTH, it) }
                    SettingSlider("Height", s.heightDp, 16f..56f, "dp") { save(Keys.HEIGHT, it) }
                    SettingSlider("Horizontal offset", s.offsetXDp, -120f..120f, "dp") { save(Keys.OFFSET_X, it) }
                    SettingSlider("Vertical offset", s.offsetYDp, -24f..48f, "dp") { save(Keys.OFFSET_Y, it) }
                    SettingSlider("Corner radius (expanded)", s.cornerRadiusDp, 8f..48f, "dp") { save(Keys.CORNER, it) }
                }
            }

            item {
                Section("Appearance and feel") {
                    Text("Color", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Swatches.forEach { argb ->
                            val selected = s.colorArgb == argb.toInt()
                            Column(
                                Modifier
                                    .size(36.dp)
                                    .background(Color(argb), CircleShape)
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) MaterialTheme.colorScheme.primary else Color.Gray,
                                        shape = CircleShape,
                                    )
                                    .clickable { save(Keys.COLOR, argb.toInt()) },
                            ) {}
                        }
                    }
                    val red = (s.colorArgb shr 16) and 0xFF
                    val green = (s.colorArgb shr 8) and 0xFF
                    val blue = s.colorArgb and 0xFF
                    fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    SettingSlider("Red", red.toFloat(), 0f..255f, "") { save(Keys.COLOR, rgb(it.toInt(), green, blue)) }
                    SettingSlider("Green", green.toFloat(), 0f..255f, "") { save(Keys.COLOR, rgb(red, it.toInt(), blue)) }
                    SettingSlider("Blue", blue.toFloat(), 0f..255f, "") { save(Keys.COLOR, rgb(red, green, it.toInt())) }
                    SettingSlider("Animation speed", s.animSpeed, 0.5f..2f, "x") { save(Keys.ANIM_SPEED, it) }
                    SwitchRow("Haptic tick on expand", s.hapticsEnabled) { save(Keys.HAPTICS, it) }
                    SwitchRow("Hide in fullscreen apps", s.hideInFullscreen) { save(Keys.HIDE_FULLSCREEN, it) }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Keeps a local value while dragging and only writes to DataStore when the drag ends. */
@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onCommit: (Float) -> Unit,
) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            val shown = if (range.endInclusive > 100f) "%d".format(local.toInt()) else "%.1f".format(local)
            Text("$shown$unit", style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value = local,
            onValueChange = { local = it },
            valueRange = range,
            onValueChangeFinished = { onCommit(local) },
        )
    }
}
