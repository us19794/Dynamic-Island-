package dev.island.dynamic.system

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import dev.island.dynamic.ServiceLocator
import dev.island.dynamic.model.IslandEvent
import dev.island.dynamic.model.MediaInfo

/**
 * Follows the most relevant active MediaSession. Must be created from the
 * NotificationListenerService because getActiveSessions() requires notification access.
 */
class MediaMonitor(
    private val context: Context,
    private val listenerComponent: ComponentName,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val sessions: MediaSessionManager? = context.getSystemService(MediaSessionManager::class.java)
    private var started = false
    private var active: MediaController? = null
    private var lastArtSource: Bitmap? = null
    private var lastArtScaled: ImageBitmap? = null

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        select(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onSessionDestroyed() = select(currentSessions())
    }

    fun start() {
        val manager = sessions ?: return
        if (started) return
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, handler)
            started = true
            select(manager.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            Log.w(TAG, "No notification access yet", e)
        }
    }

    fun stop() {
        if (started) {
            runCatching { sessions?.removeOnActiveSessionsChangedListener(sessionsListener) }
            started = false
        }
        swap(null)
        ServiceLocator.machine.dispatch(IslandEvent.MediaChanged(null))
    }

    private fun currentSessions(): List<MediaController> = try {
        sessions?.getActiveSessions(listenerComponent).orEmpty()
    } catch (_: SecurityException) {
        emptyList()
    }

    private fun select(list: List<MediaController>) {
        val usable = list.filter { it.packageName != context.packageName && it.metadata != null }
        val chosen = usable.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: usable.firstOrNull()
        if (chosen?.sessionToken != active?.sessionToken) swap(chosen)
        publish()
    }

    private fun swap(next: MediaController?) {
        runCatching { active?.unregisterCallback(callback) }
        active = next
        MediaBridge.controller = next
        next?.registerCallback(callback, handler)
    }

    private fun publish() {
        val controller = active
        if (controller == null) {
            ServiceLocator.machine.dispatch(IslandEvent.MediaChanged(null))
            return
        }
        val metadata = controller.metadata
        val state = controller.playbackState
        if (metadata == null || state == null ||
            state.state == PlaybackState.STATE_NONE || state.state == PlaybackState.STATE_STOPPED
        ) {
            ServiceLocator.machine.dispatch(IslandEvent.MediaChanged(null))
            return
        }
        ServiceLocator.machine.dispatch(IslandEvent.MediaChanged(build(controller, metadata, state)))
    }

    private fun build(c: MediaController, md: MediaMetadata, st: PlaybackState): MediaInfo {
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE).orEmpty()
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE).orEmpty()
        val rawArt = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val art = scaledArt(rawArt) ?: AppIcons.get(context, c.packageName)
        val duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val playing = st.state == PlaybackState.STATE_PLAYING || st.state == PlaybackState.STATE_BUFFERING
        val actions = st.actions
        return MediaInfo(
            packageName = c.packageName,
            title = title,
            artist = artist,
            art = art,
            isPlaying = playing,
            positionMs = st.position.coerceAtLeast(0L),
            positionUpdatedAtElapsed = if (st.lastPositionUpdateTime > 0) st.lastPositionUpdateTime else SystemClock.elapsedRealtime(),
            speed = if (st.playbackSpeed == 0f) 1f else st.playbackSpeed,
            durationMs = duration.coerceAtLeast(0L),
            canSeek = actions and PlaybackState.ACTION_SEEK_TO != 0L,
            canNext = actions and PlaybackState.ACTION_SKIP_TO_NEXT != 0L,
            canPrevious = actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS != 0L,
        )
    }

    /** Scale once per distinct source bitmap; playback-state updates reuse the result. */
    private fun scaledArt(source: Bitmap?): ImageBitmap? {
        if (source == null) return null
        if (source === lastArtSource) return lastArtScaled
        val max = 256
        val scale = minOf(1f, max.toFloat() / maxOf(source.width, source.height))
        val bitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true)
        } else {
            source
        }
        lastArtSource = source
        lastArtScaled = bitmap.asImageBitmap()
        return lastArtScaled
    }

    private companion object {
        const val TAG = "MediaMonitor"
    }
}
