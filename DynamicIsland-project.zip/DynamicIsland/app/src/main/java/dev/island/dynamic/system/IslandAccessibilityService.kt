package dev.island.dynamic.system

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Optional, best-effort fullscreen detection. It never reads window content: it only looks
 * at window types and bounds to see whether the system status bar window is still on screen.
 * "Fullscreen" is only reported after a status bar window has been seen at least once,
 * so devices that don't expose it can never leave the island hidden.
 */
class IslandAccessibilityService : AccessibilityService() {

    private var statusBarSeen = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        evaluate()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        evaluate()
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        OverlayBus.a11yFullscreen.value = false
        return super.onUnbind(intent)
    }

    private fun evaluate() {
        try {
            val windows = windows
            val maxBarHeight = resources.displayMetrics.heightPixels / 8
            val bounds = Rect()
            var statusBarPresent = false
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_SYSTEM) continue
                w.getBoundsInScreen(bounds)
                if (bounds.top <= 0 && bounds.height() in 1..maxBarHeight) {
                    // Ignore our own overlay, which is also a small top-aligned system window.
                    if (w.root?.packageName != packageName) statusBarPresent = true
                }
            }
            if (statusBarPresent) statusBarSeen = true
            OverlayBus.a11yFullscreen.value = statusBarSeen && !statusBarPresent
        } catch (_: Throwable) {
            OverlayBus.a11yFullscreen.value = false
        }
    }
}
