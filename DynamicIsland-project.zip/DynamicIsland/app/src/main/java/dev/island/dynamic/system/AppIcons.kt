package dev.island.dynamic.system

import android.content.Context
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

object AppIcons {
    private val cache = LruCache<String, ImageBitmap>(48)

    fun get(context: Context, packageName: String): ImageBitmap? {
        cache.get(packageName)?.let { return it }
        return try {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = drawable.toBitmap(96, 96).asImageBitmap()
            cache.put(packageName, bitmap)
            bitmap
        } catch (_: Throwable) {
            null
        }
    }
}
