package dev.island.dynamic.settings

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.island.dynamic.model.CallInfo
import dev.island.dynamic.model.ChargingInfo
import dev.island.dynamic.model.IslandActivity
import dev.island.dynamic.model.MediaInfo
import dev.island.dynamic.model.NotificationInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.io.IOException

private val Context.islandDataStore by preferencesDataStore(name = "island_settings")

@Immutable
data class IslandSettings(
    /** False only until DataStore has delivered its first value. */
    val loaded: Boolean = false,
    val serviceEnabled: Boolean = true,
    val onboardingDone: Boolean = false,
    /** Align to the DisplayCutout. When off, width/height/offsets are used as absolute manual values. */
    val autoAlign: Boolean = true,
    val widthDp: Float = 56f,
    val heightDp: Float = 26f,
    val offsetXDp: Float = 0f,
    val offsetYDp: Float = 0f,
    val cornerRadiusDp: Float = 30f,
    val colorArgb: Int = 0xFF000000.toInt(),
    val animSpeed: Float = 1f,
    val notificationsEnabled: Boolean = true,
    val mediaEnabled: Boolean = true,
    val callsEnabled: Boolean = true,
    val chargingEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val hideInFullscreen: Boolean = true,
    val disabledApps: Set<String> = emptySet(),
) {
    fun allows(activity: IslandActivity): Boolean = when (activity) {
        is NotificationInfo -> notificationsEnabled && activity.packageName !in disabledApps
        is MediaInfo -> mediaEnabled
        is CallInfo -> callsEnabled
        is ChargingInfo -> chargingEnabled
    }
}

object Keys {
    val SERVICE_ENABLED = booleanPreferencesKey("service_enabled")
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    val AUTO_ALIGN = booleanPreferencesKey("auto_align")
    val WIDTH = floatPreferencesKey("width_dp")
    val HEIGHT = floatPreferencesKey("height_dp")
    val OFFSET_X = floatPreferencesKey("offset_x_dp")
    val OFFSET_Y = floatPreferencesKey("offset_y_dp")
    val CORNER = floatPreferencesKey("corner_dp")
    val COLOR = intPreferencesKey("color_argb")
    val ANIM_SPEED = floatPreferencesKey("anim_speed")
    val NOTIFICATIONS = booleanPreferencesKey("type_notifications")
    val MEDIA = booleanPreferencesKey("type_media")
    val CALLS = booleanPreferencesKey("type_calls")
    val CHARGING = booleanPreferencesKey("type_charging")
    val HAPTICS = booleanPreferencesKey("haptics")
    val HIDE_FULLSCREEN = booleanPreferencesKey("hide_fullscreen")
    val DISABLED_APPS = stringSetPreferencesKey("disabled_apps")
}

private fun Preferences.toSettings(): IslandSettings {
    val d = IslandSettings()
    return IslandSettings(
        loaded = true,
        serviceEnabled = this[Keys.SERVICE_ENABLED] ?: d.serviceEnabled,
        onboardingDone = this[Keys.ONBOARDING_DONE] ?: d.onboardingDone,
        autoAlign = this[Keys.AUTO_ALIGN] ?: d.autoAlign,
        widthDp = this[Keys.WIDTH] ?: d.widthDp,
        heightDp = this[Keys.HEIGHT] ?: d.heightDp,
        offsetXDp = this[Keys.OFFSET_X] ?: d.offsetXDp,
        offsetYDp = this[Keys.OFFSET_Y] ?: d.offsetYDp,
        cornerRadiusDp = this[Keys.CORNER] ?: d.cornerRadiusDp,
        colorArgb = this[Keys.COLOR] ?: d.colorArgb,
        animSpeed = this[Keys.ANIM_SPEED] ?: d.animSpeed,
        notificationsEnabled = this[Keys.NOTIFICATIONS] ?: d.notificationsEnabled,
        mediaEnabled = this[Keys.MEDIA] ?: d.mediaEnabled,
        callsEnabled = this[Keys.CALLS] ?: d.callsEnabled,
        chargingEnabled = this[Keys.CHARGING] ?: d.chargingEnabled,
        hapticsEnabled = this[Keys.HAPTICS] ?: d.hapticsEnabled,
        hideInFullscreen = this[Keys.HIDE_FULLSCREEN] ?: d.hideInFullscreen,
        disabledApps = this[Keys.DISABLED_APPS] ?: d.disabledApps,
    )
}

class SettingsRepository(private val context: Context, scope: CoroutineScope) {

    private val prefsFlow = context.islandDataStore.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val settings: StateFlow<IslandSettings> = prefsFlow
        .map { it.toSettings() }
        .stateIn(scope, SharingStarted.Eagerly, IslandSettings())

    /** One-shot read for places that can't wait on the StateFlow (e.g. BootReceiver). */
    suspend fun readOnce(): IslandSettings = prefsFlow.first().toSettings()

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        context.islandDataStore.edit { it[key] = value }
    }

    suspend fun setAppEnabled(packageName: String, enabled: Boolean) {
        context.islandDataStore.edit { prefs ->
            val current = prefs[Keys.DISABLED_APPS] ?: emptySet()
            prefs[Keys.DISABLED_APPS] = if (enabled) current - packageName else current + packageName
        }
    }
}
