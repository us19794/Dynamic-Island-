package dev.island.dynamic.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import dev.island.dynamic.ServiceLocator
import kotlinx.coroutines.runBlocking

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (!Permissions.hasOverlay(context)) return
        val enabled = try {
            runBlocking { ServiceLocator.repo.readOnce().serviceEnabled }
        } catch (_: Throwable) {
            true
        }
        if (enabled) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
            } catch (_: Throwable) {
                // Background start can be refused on some OEM builds; the user can open the app.
            }
        }
    }
}
