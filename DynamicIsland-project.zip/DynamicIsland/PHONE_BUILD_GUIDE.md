# Build the APK from your phone (no computer)

You need a free GitHub account. Everything below works in a phone browser.

1. Go to github.com, sign in, tap **+ > New repository**. Name it `island`, keep it Public (free Actions minutes are unlimited for public repos), tap **Create repository**.
2. In the new repo tap **Add file > Upload files**, choose `DynamicIsland-project.zip` (leave it zipped), then **Commit changes**.
3. Tap **Add file > Create new file**. In the name box type exactly `.github/workflows/build.yml` (typing the slashes creates the folders). Open the provided `build.yml`, copy all its text into the editor, then **Commit changes**.
4. Open the **Actions** tab. The "Build debug APK" run starts automatically (or tap it > **Run workflow**). It takes about 5-10 minutes the first time.
5. When it is green, go back to the repo's main page and tap **Releases** (right side, "Debug build N"). Tap `app-debug.apk` to download it.
   (Alternative: open the run and download the `DynamicIsland-debug-apk` artifact, which is a zip containing the APK.)
6. Open the downloaded APK. Android asks to allow installs from your browser: allow it, then install. If Play Protect warns about an unknown app, choose "Install anyway".
7. Open Island and follow the setup screen. For step 3/4 see "Sideloading on Android 16" in README.md.

If the build fails, open the failed run, tap the failing step, and send me the last ~40 lines of the log. I'll fix it.
