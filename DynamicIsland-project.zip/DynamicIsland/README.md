# Island: a Dynamic Island clone for Android

Kotlin + Jetpack Compose (Material 3), minSdk 29, target/compileSdk 36. No third-party UI or animation libraries.

## Build
No Gradle wrapper jar is checked in (it is a binary that could not be generated offline). Either:
- **GitHub Actions (phone only):** see `PHONE_BUILD_GUIDE.md`. The workflow installs Gradle 8.11.1 and builds `app-debug.apk`.
- **Computer:** install JDK 17 + Android SDK 36, run `gradle wrapper --gradle-version 8.11.1` once, then `./gradlew assembleDebug`.

## Permissions
| Permission | Why |
|---|---|
| Display over other apps (`SYSTEM_ALERT_WINDOW`) | Draws the island window |
| Notification access (listener) | Notifications, media sessions, incoming/ongoing calls |
| `POST_NOTIFICATIONS` | Shows the foreground-service notification |
| Battery: Unrestricted | Nothing OS kills background apps otherwise |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Foreground service type for the overlay |
| `VIBRATE` | Haptic tick on expand |
| Accessibility (optional) | Best-effort hide in fullscreen/immersive apps; reads only window types and bounds |

## Sideloading on Android 16
1. Allow your browser/Files app to "Install unknown apps", then open the APK.
2. Notification access is blocked for sideloaded apps ("Restricted settings"). Settings > Apps > Island > top-right menu > **Allow restricted settings**. The menu appears after you have tried to enable Notification access once. Then enable Notification access again.
3. Settings > Apps > Island > Battery > **Unrestricted**, and lock the app in Recents (long-press its card > Lock).

## Tuning the animation
Everything lives in `ui/island/IslandMotion.kt` (`IslandSpring`):
- `DAMPING` (0.76): lower = bouncier (0.70), higher = calmer (0.85), 1.0 = no overshoot.
- `STIFFNESS` (420): 300-500 is the usable range; higher is snappier.
- `STAGGER_MS` (80): delay before content fades in after the container starts moving.
- `FADE_IN_STIFFNESS` / `FADE_OUT_STIFFNESS`: content fade speeds.
The in-app "Animation speed" slider multiplies stiffness by speed^2, which scales time without changing bounciness.

## Architecture
- `model/IslandStateMachine`: one channel, one reducer, `StateFlow<IslandState>`. Timers are delayed events.
- `ui/island`: UI is a pure function of state. Width/height/radius animate as one `Animatable<IslandShape>` and are read only in draw lambdas.
- `system/OverlayService`: foreground service hosting the ComposeView in a `TYPE_APPLICATION_OVERLAY` window, sized to the current form.
- `system/IslandNotificationListener` + `MediaMonitor`: notifications, calls (from CallStyle/call-category notifications, answer/decline via their PendingIntents) and media sessions.
- Cutout alignment uses `WindowMetrics.windowInsets.displayCutout`; if unavailable, turn off auto-align and use the manual sliders.

## NameDrop-style animation (animation only)
A visual-only effect: a blue/purple/pink glow fades in from the top edge, and ~350 ms later a dark contact card springs up from the bottom. No NFC, proximity, sharing or networking, and no extra permissions.
- **Trigger:** long-press the island while it is idle, or tap **NameDrop** under Preview in the app. Placeholder name/number live in `model/NameDrop.kt`.
- **Dismiss:** tap anywhere outside the card. Share / Receive Only just dismiss for now (`NameDropHost` in `ui/namedrop/NameDropOverlay.kt`).
- **Window:** a separate full-screen overlay window that exists only while the animation is visible (touchable only then, removed afterwards), so it never blocks the apps underneath.
- **Blur:** on Android 12+ the app behind is blurred with window blur-behind (needs cross-window blur enabled on the device). `Modifier.blur` is not used because it can only blur a composable's own content.
- **Tuning:** `NameDropMotion` at the top of `NameDropOverlay.kt` (delay, bounce, drift/pulse speed, scrim).
